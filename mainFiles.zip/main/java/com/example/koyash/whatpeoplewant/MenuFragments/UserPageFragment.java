package com.example.koyash.whatpeoplewant.MenuFragments;


import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.koyash.whatpeoplewant.CommentFragment;
import com.example.koyash.whatpeoplewant.MultipartEntity;
import com.example.koyash.whatpeoplewant.OpenPhoto;
import com.example.koyash.whatpeoplewant.R;
import com.example.koyash.whatpeoplewant.createNewWish;
import com.squareup.picasso.Picasso;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class UserPageFragment extends Fragment implements View.OnClickListener{

    final String url = "http://wpw.tmweb.ru/API.php";
    final String urlImage = "http://wpw.tmweb.ru/";
    String response;

    String wish_state;
    TextView a1, a2, a3, userswishes;

    int choise, likeordislike = 0;

    JSONObject wishObject;
    JSONArray wishArray;
    List<String> wish = new ArrayList<String>();
    List<String> num = new ArrayList<String>();
    List<String> wish_image = new ArrayList<String>();
    List<Integer> wish_id = new ArrayList<Integer>();
    List<Integer> state = new ArrayList<Integer>();
    List<Integer> apllied = new ArrayList<Integer>();
    List<Integer> commendCount = new ArrayList<Integer>();
    List<Integer> reportCount = new ArrayList<Integer>();
    RecyclerView rv;

    SharedPreferences sPref;

    ImageView usersPage, abc;
    ImageView editUser, addwish;

    Bitmap bitmap;

    boolean isImageFitToScreen;

    CollapsingToolbarLayout toolbar;

    View view;

    Button createIdea;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.activity_user_page_fragment, container,
                false);


        sPref = this.getActivity().getSharedPreferences("APP", getActivity().MODE_PRIVATE);

        toolbar = (CollapsingToolbarLayout)view.findViewById(R.id.toolbar_layout);

        a1 = (TextView) view.findViewById(R.id.textView16);
        a3 = (TextView) view.findViewById(R.id.cityAndCountry);
        userswishes = (TextView) view.findViewById(R.id.noUsersWishes);

        usersPage = (ImageView) view.findViewById(R.id.backgroundImageView);
        abc = (ImageView) view.findViewById(R.id.abc);

        abc.setOnClickListener(this);

        createIdea = (Button) view.findViewById(R.id.createIdea);

        createIdea.setOnClickListener(this);

        LinearLayoutManager llm;
        llm = new LinearLayoutManager(getContext());

        toolbar.setTitle(sPref.getString("surname","") + " " + sPref.getString("name"," "));

        try {
            a3.setText(sPref.getString("country", null) + ", " + sPref.getString("city", null));
            if (!sPref.getString("photo", null).equals("") && !sPref.getString("photo", null).equals(null))
                Picasso.with(getActivity()).load(urlImage + sPref.getString("photo", null)).into(usersPage);
            else
                usersPage.setImageResource(R.drawable.user);

        } catch (Exception e) {
            Log.d("MYLOGS",e + " - e");
            usersPage.setImageResource(R.drawable.user);
        }

        rv = (RecyclerView) view.findViewById(R.id.users_page_recycler_view);
        rv.setLayoutManager(llm);

        usersPage.setOnClickListener(this);

        getUsersWish();

        setHasOptionsMenu(true);

        userswishes.setText(" ");

        return view;

    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.menu_user_page, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // handle item selection
        switch (item.getItemId()) {
            case R.id.action_change_info:
                Intent intent = new Intent(getActivity(),EditUsersInfoFragment.class);
                startActivity(intent);
                return true;
            case R.id.action_add_wish:
                Intent intent1 = new Intent(getActivity(), createNewWish.class);
                startActivity(intent1);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    private void selectImage() {

        final CharSequence[] options = { getString(R.string.Open), getString(R.string.TakePhoto), getString(R.string.Choose),getString(R.string.Cancel) };

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (options[item].equals(options[0])){
                    Intent intent = new Intent(getActivity(),OpenPhoto.class);
                    intent.putExtra("photo_path",urlImage+sPref.getString("photo",""));
                    startActivity(intent);
                }
                else if (options[item].equals(options[1]))
                {
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    File f = new File(android.os.Environment.getExternalStorageDirectory(), "temp.jpg");
                    intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(f));
                    startActivityForResult(intent, 1);
                }
                else if (options[item].equals(options[2]))
                {
                    Intent intent = new   Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(intent, 2);

                }
                else if (options[item].equals(options[3])) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    String picturePath;
    Uri selectedImage;

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == getActivity().RESULT_OK) {
            if (requestCode == 1) {
                File f = new File(Environment.getExternalStorageDirectory().toString());
                for (File temp : f.listFiles()) {
                    if (temp.getName().equals("temp.jpg")) {
                        f = temp;
                        break;
                    }
                }
                try {
                    BitmapFactory.Options bitmapOptions = new BitmapFactory.Options();

                    bitmap = BitmapFactory.decodeFile(f.getAbsolutePath(),
                            bitmapOptions);

                    ByteArrayOutputStream stream=new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.PNG, 90, stream);
                    byte[] image=stream.toByteArray();
                    String img_str = Base64.encodeToString(image, 0);
                    byte[] imageAsBytes = Base64.decode(img_str.getBytes(), Base64.DEFAULT);
                    usersPage.setImageBitmap(BitmapFactory.decodeByteArray(imageAsBytes,0, imageAsBytes.length) );
                    uploadPhoto();

                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (requestCode == 2) {

                selectedImage = data.getData();
                String[] filePath = { MediaStore.Images.Media.DATA };
                Cursor c = getActivity().getContentResolver().query(selectedImage,filePath, null, null, null);
                c.moveToFirst();
                int columnIndex = c.getColumnIndex(filePath[0]);
                picturePath = c.getString(columnIndex);
                c.close();
                bitmap = (BitmapFactory.decodeFile(picturePath));
                ByteArrayOutputStream stream=new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 90, stream);
                byte[] image=stream.toByteArray();
                String img_str = Base64.encodeToString(image, 0);
                byte[] imageAsBytes = Base64.decode(img_str.getBytes(), Base64.DEFAULT);
                usersPage.setImageBitmap(BitmapFactory.decodeByteArray(imageAsBytes,0, imageAsBytes.length) );
                uploadPhoto();

            }
        }
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.abc:
                selectImage();
                break;
            case R.id.createIdea:
                Intent intent1 = new Intent(getActivity(), createNewWish.class);
                startActivity(intent1);
                break;
            default:
                break;
        }
    }

    class WishesConteiner {

        String wish;
        String count;
        String wish_image;
        int state;
        int wish_id;
        int applyState;
        int reportCount;
        int commendCount;

        WishesConteiner(String wish, String count, String wish_image, int state, int wish_id,int applyState,int commendCount, int reportCount) {
            this.wish = wish;
            this.count = count;
            this.wish_image = wish_image;
            this.state = state;
            this.wish_id = wish_id;
            this.applyState = applyState;
            this.commendCount = commendCount;
            this.reportCount = reportCount;
        }

    }

    private List<WishesConteiner> wishes;

    private void initializeData() {
        wishes = new ArrayList<>();
        rv.setAdapter(null);
        if (wish.size() > 0) {
            for (int i = 0; i < wish.size(); i++) {
                wishes.add(new WishesConteiner(wish.get(i), num.get(i), wish_image.get(i), state.get(i), wish_id.get(i), apllied.get(i), commendCount.get(i), reportCount.get(i)));
            }
        }
        else{
            userswishes.setText(getString(R.string.NoWishes));
        }
    }

    public class RVAdapter extends RecyclerView.Adapter<RVAdapter.WishViewHolder> {

        List<WishesConteiner> wishes;
        public RVAdapter(List<WishesConteiner> wishes) {
            this.wishes = wishes;
        }

        @Override
        public WishViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.user_page_card_view_adapter, viewGroup, false);
            WishViewHolder wishViewHolder = new WishViewHolder(v);
            return wishViewHolder;
        }

        @Override
        public void onBindViewHolder(final WishViewHolder wishViewHolder, final int i) {
            wishViewHolder.wishTextView.setText(wishes.get(i).wish);
            wishViewHolder.countTextView.setText(wishes.get(i).count);
            wishViewHolder.commendCount.setText(String.valueOf(wishes.get(i).commendCount));

            if (!wishes.get(i).wish_image.equals(null) || !wishes.get(i).wish_image.equals("Uploads/")) {
                Picasso.with(getActivity()).load(urlImage + wishes.get(i).wish_image).into(wishViewHolder.wishImage );
            }
            if (wishes.get(i).state == 1) {
                wishViewHolder.likeImageView.setImageResource(R.drawable.shadedlike);
            }
            if (wishes.get(i).state == -1) {
                wishViewHolder.dislikeImageView.setImageResource(R.drawable.shadeddislike);
            }
            if (wishes.get(i).state == 0) {
                wishViewHolder.likeImageView.setImageResource(R.drawable.like);
                wishViewHolder.dislikeImageView.setImageResource(R.drawable.dislike);
            }
            if (wishes.get(i).applyState == 1){
                wishViewHolder.applyImageView.setImageResource(R.drawable.shadeddone);
                wishViewHolder.doneTextView.setVisibility(View.VISIBLE);
            }
            else{
                wishViewHolder.doneTextView.setVisibility(View.INVISIBLE);
                wishViewHolder.applyImageView.setImageResource(R.drawable.done);
            }

            wishViewHolder.likeImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    choise = wishes.get(i).wish_id;
                    int count = Integer.parseInt(wishes.get(i).count);
                    if (wishes.get(i).state == 0) {
                        likeordislike = 1;
                        wishes.get(i).state = 1;
                        wishes.get(i).count = String.valueOf(count + 1);
                        wishViewHolder.likeImageView.setImageResource(R.drawable.shadedlike);
                        wishViewHolder.dislikeImageView.setImageResource(R.drawable.dislike);
                        wishViewHolder.countTextView.setText(String.valueOf(wishes.get(i).count));
                    } else if (wishes.get(i).state == -1) {
                        likeordislike = 1;
                        wishes.get(i).state = 1;
                        wishes.get(i).count = String.valueOf(count + 2);
                        wishViewHolder.likeImageView.setImageResource(R.drawable.shadedlike);
                        wishViewHolder.dislikeImageView.setImageResource(R.drawable.dislike);
                        wishViewHolder.countTextView.setText(String.valueOf(wishes.get(i).count));
                    } else if (wishes.get(i).state == 1) {
                        likeordislike = 0;
                        wishes.get(i).state = 0;
                        wishes.get(i).count = String.valueOf(count - 1);
                        wishViewHolder.countTextView.setText(String.valueOf(wishes.get(i).count));
                        wishViewHolder.likeImageView.setImageResource(R.drawable.like);
                        wishViewHolder.dislikeImageView.setImageResource(R.drawable.dislike);
                    }
                    try {
                        sendRateWish(i);
                    }
                    catch (Exception e){
                        Toast.makeText(getActivity(),getString(R.string.NoInternetConnection),Toast.LENGTH_SHORT).show();
                    }
                }
            });
            wishViewHolder.dislikeImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    choise = wishes.get(i).wish_id;
                    int count = Integer.parseInt(wishes.get(i).count);
                    if (wishes.get(i).state == 0) {
                        likeordislike = -1;
                        wishes.get(i).state = -1;
                        wishes.get(i).count = String.valueOf(count - 1);
                        wishViewHolder.likeImageView.setImageResource(R.drawable.like);
                        wishViewHolder.dislikeImageView.setImageResource(R.drawable.shadeddislike);
                        wishViewHolder.countTextView.setText(String.valueOf(wishes.get(i).count));
                    } else if (wishes.get(i).state == 1) {
                        likeordislike = -1;
                        wishes.get(i).state = -1;
                        wishes.get(i).count = String.valueOf(count - 2);
                        wishViewHolder.likeImageView.setImageResource(R.drawable.like);
                        wishViewHolder.dislikeImageView.setImageResource(R.drawable.shadeddislike);
                        wishViewHolder.countTextView.setText(String.valueOf(wishes.get(i).count));
                    } else if (wishes.get(i).state == -1) {
                        likeordislike = 0;
                        wishes.get(i).state = 0;
                        wishes.get(i).count = String.valueOf(count + 1);
                        wishViewHolder.countTextView.setText(String.valueOf(wishes.get(i).count));
                        wishViewHolder.likeImageView.setImageResource(R.drawable.like);
                        wishViewHolder.dislikeImageView.setImageResource(R.drawable.dislike);
                    }
                    try {
                        sendRateWish(i);
                    }
                    catch (Exception e){
                        Toast.makeText(getActivity(),getString(R.string.NoInternetConnection),Toast.LENGTH_SHORT).show();
                    }

                }
            });
            wishViewHolder.trashImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    choise = wishes.get(i).wish_id;

                    AlertDialog ad = new AlertDialog.Builder(getActivity())
                            .create();
                    ad.setCancelable(true);
                    ad.setTitle(getString(R.string.DeleteWish));
                    ad.setMessage(getString(R.string.AreYouSure));
                    ad.setButton(getString(R.string.yes), new DialogInterface.OnClickListener() {

                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            deleteSelectedWish();
                        }
                    });
                    ad.show();
                }
            });
            wishViewHolder.shareImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent sendIntent = new Intent();
                    sendIntent.setAction(Intent.ACTION_SEND);
                    sendIntent.putExtra(Intent.EXTRA_TEXT, "Hey, check it!)) " + "wpw.tmweb.ru/" + wishes.get(i).wish_id);
                    sendIntent.setType("text/plain");
                    startActivity(sendIntent);
                }
            });
            wishViewHolder.commendIamgeView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    choise = wishes.get(i).wish_id;
                    SharedPreferences.Editor ed = sPref.edit();
                    ed.putString("nameAndSurname", sPref.getString("surname","") + " " + sPref.getString("name"," "));
                    ed.putString("wishText",wishes.get(i).wish);
                    ed.putString("choise", String.valueOf(choise));
                    ed.putString("user",sPref.getString("userId",""));
                    if (!sPref.getString("photo", null).equals("") && !sPref.getString("photo", null).equals(null)) {
                        ed.putString("userPage", sPref.getString("photo", ""));
                    }
                    ed.apply();
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.replace(R.id.flContent, new CommentFragment(), "fragment_screen");
                    ft.addToBackStack(null);
                    ft.commit();
                }
            });
            wishViewHolder.applyImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    choise = wishes.get(i).wish_id;
                    if (wishes.get(i).applyState == 0) {
                        AlertDialog ad = new AlertDialog.Builder(getActivity())
                                .create();
                        ad.setCancelable(true);
                        ad.setMessage(getString(R.string.Congratulations));
                        ad.setButton(getString(R.string.yes), new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                        ad.show();
                        wishViewHolder.applyImageView.setImageResource(R.drawable.shadeddone);
                        wishViewHolder.doneTextView.setVisibility(View.VISIBLE);
                        wish_state = String.valueOf(wishes.get(i).applyState);
                        performSelectedWish();
                        wishes.get(i).applyState = 1;
                    }
                    else{
                        choise = wishes.get(i).wish_id;
                        wishViewHolder.applyImageView.setImageResource(R.drawable.done);
                        wishViewHolder.doneTextView.setVisibility(View.INVISIBLE);
                        wish_state = String.valueOf(wishes.get(i).applyState);
                        performSelectedWish();
                        wishes.get(i).applyState = 0;
                    }
                }
            });
            wishViewHolder.wishImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(isImageFitToScreen) {
                        isImageFitToScreen=false;
                        wishViewHolder.wishImage.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                        wishViewHolder.wishImage.setAdjustViewBounds(true);
                    }else{
                        isImageFitToScreen=true;
                        wishViewHolder.wishImage.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
                        wishViewHolder.wishImage.setScaleType(ImageView.ScaleType.FIT_XY);
                    }
                }
            });

        }

        @Override
        public int getItemCount() {
            return wishes.size();
        }

        @Override
        public void onAttachedToRecyclerView(RecyclerView recyclerView) {
            super.onAttachedToRecyclerView(recyclerView);
        }

        public class WishViewHolder extends RecyclerView.ViewHolder {

            CardView cv;
            TextView wishTextView;
            TextView countTextView;
            TextView doneTextView;
            ImageView likeImageView;
            ImageView dislikeImageView;
            ImageView trashImageView;
            ImageView shareImageView;
            ImageView commendIamgeView;
            ImageView applyImageView;
            ImageView wishImage;
            TextView commendCount;
            TextView reportCount;
            WishViewHolder(View itemView) {
                super(itemView);
                cv = (CardView)itemView.findViewById(R.id.cv);
                wishTextView = (TextView)itemView.findViewById(R.id.wishTextView);
                countTextView = (TextView)itemView.findViewById(R.id.countTextView);
                doneTextView = (TextView)itemView.findViewById(R.id.doneTextView);
                likeImageView = (ImageView)itemView.findViewById(R.id.likeImageView);
                dislikeImageView = (ImageView)itemView.findViewById(R.id.dislikeImageView);
                trashImageView = (ImageView)itemView.findViewById(R.id.deleteImageView);
                shareImageView = (ImageView)itemView.findViewById(R.id.imageView3);
                commendIamgeView = (ImageView)itemView.findViewById(R.id.userCommendImageView);
                applyImageView = (ImageView)itemView.findViewById(R.id.imageView4);
                wishImage = (ImageView)itemView.findViewById(R.id.wishImage);
                commendCount = (TextView) itemView.findViewById(R.id.commendCountUserPage);
            }
        }

    }

    public void getUsersWish(){
        usersWish userswish = new usersWish();
        userswish.execute("");
    }

    private class usersWish extends AsyncTask<String, Void, Void>{

        @Override
        protected void onPreExecute() {
            rv.setAdapter(null);
        }

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code","usersWishes");
            multipartEntity.addPart("user_id",sPref.getString("userId",null));
            multipartEntity.addPart("lang", Locale.getDefault().getLanguage());

            httpPost.setEntity(multipartEntity);
            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                response = EntityUtils.toString(entity);

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        public void onPostExecute(Void o) {
            super.onPostExecute(o);
            if (response != null) {
                try {
                    wishObject = new JSONObject(response);
                    if (wishObject != null) {
                        wish = new ArrayList<String>();
                        num = new ArrayList<String>();
                        wish_image = new ArrayList<String>();
                        commendCount = new ArrayList<Integer>();
                        reportCount = new ArrayList<Integer>();
                        wish_id = new ArrayList<Integer>();
                        state = new ArrayList<Integer>();
                        apllied = new ArrayList<Integer>();
                        wishArray = wishObject.getJSONArray("usersWishes");
                        for (int i = 0; i < wishArray.length(); i++) {
                            JSONObject catObj = (JSONObject) wishArray.get(i);
                            num.add(catObj.getString("count_likes"));
                            wish_image.add(catObj.getString("wish_image_path"));
                            wish.add(catObj.getString("wish"));
                            wish_id.add(catObj.getInt("wish_id"));
                            state.add(catObj.getInt("state"));
                            apllied.add(catObj.getInt("wish_state"));
                            reportCount.add(catObj.getInt("count_reports"));
                            commendCount.add(catObj.getInt("count_comments"));
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            try {
                getActivity().findViewById(R.id.loadingPanelUser).setVisibility(View.GONE);
            } catch (Exception e) {

            }
            try {
                rv.setAdapter(null);
                initializeData();
                RVAdapter adapter = new RVAdapter(wishes);
                rv.setAdapter(adapter);
            }
            catch (Exception e){
                rv.setAdapter(null);
                Toast.makeText(getActivity(),getString(R.string.NoInternetConnection),Toast.LENGTH_SHORT).show();
            }
        }

    }

    public void sendRateWish(int position){
        rateWish retewish = new rateWish();
        retewish.execute("");
    }

    private class rateWish extends AsyncTask<String, Void, Void> {
        private rateWish() {

        }

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code","ratewish");
            multipartEntity.addPart("user_id", sPref.getString("userId", null));
            multipartEntity.addPart("wish_id", String.valueOf(choise));
            multipartEntity.addPart("state", String.valueOf(likeordislike));


            httpPost.setEntity(multipartEntity);
            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                response = EntityUtils.toString(entity);

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        public void onPostExecute(Void o){
            super.onPostExecute(o);
        }
    }

    public void deleteSelectedWish(){
        deleteWish deletewish = new deleteWish();
        deletewish.execute("");
    }

    private class deleteWish extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code","delete");
            multipartEntity.addPart("wish_id", String.valueOf(choise));

            httpPost.setEntity(multipartEntity);
            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                response = EntityUtils.toString(entity);

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        public void onPostExecute(Void o){
            super.onPostExecute(o);
            if (response.equals("11")){
                getUsersWish();
            }
        }
    }

    public void performSelectedWish(){
        performWish performwish = new performWish();
        performwish.execute("");
    }

    private class performWish extends AsyncTask<String, Void, Void> {


        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code","performWish");
            multipartEntity.addPart("wish_id", String.valueOf(choise));
            multipartEntity.addPart("wish_state", wish_state);

            httpPost.setEntity(multipartEntity);
            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                response = EntityUtils.toString(entity);

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        public void onPostExecute(Void o){
            super.onPostExecute(o);
        }
    }

    public void uploadPhoto(){
        uploadImage uploadimage = new uploadImage();
        uploadimage.execute();
    }

    private class uploadImage extends AsyncTask<String, Void, Void> {

        ProgressDialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = ProgressDialog.show(getActivity(),"",getString(R.string.savingPhoto),true,true);
        }

        @Override
        protected Void doInBackground(String... params) {

            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
            InputStream in = new ByteArrayInputStream(stream.toByteArray());

            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);

            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code","uploadUserImage");
            multipartEntity.addPart("user_id", sPref.getString("userId",null));
            multipartEntity.addPart("image",  System.currentTimeMillis() + ".jpg", in);

            httpPost.setEntity(multipartEntity);
            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                response = EntityUtils.toString(entity);

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        public void onPostExecute(Void o){
            super.onPostExecute(o);
            dialog.dismiss();
            Log.d("MYLOGS","response:" + response);
            SharedPreferences.Editor ed = sPref.edit();
            if (!response.equals(null))
                ed.putString("photo",response);
            else
                Toast.makeText(getActivity(),getString(R.string.NoInternetConnection),Toast.LENGTH_SHORT).show();
            ed.commit();
        }
    }

}
