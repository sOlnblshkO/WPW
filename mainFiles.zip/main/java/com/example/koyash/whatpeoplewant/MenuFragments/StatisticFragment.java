package com.example.koyash.whatpeoplewant.MenuFragments;


import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.content.SharedPreferences;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.koyash.whatpeoplewant.CommentFragment;
import com.example.koyash.whatpeoplewant.MultipartEntity;
import com.example.koyash.whatpeoplewant.OpenPhoto;
import com.example.koyash.whatpeoplewant.R;
import com.example.koyash.whatpeoplewant.ReportWishFragment;
import com.example.koyash.whatpeoplewant.createOffer;
import com.example.koyash.whatpeoplewant.NewUserPageFragment;
import com.squareup.picasso.Picasso;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;

public class StatisticFragment extends Fragment {

    private static final String url = "http://wpw.tmweb.ru/API.php";
    final String urlImage = "http://wpw.tmweb.ru/";

    RecyclerView rv;

    int choise,likeordislike=0;

    Spinner spinnerRegion, spinnerCity;

    JSONObject wishObject,regionObject,cityObject, newUserObject;

    JSONArray wishArray,cityArray,regionArray;

    List<String> region = new ArrayList<String>();
    List<String> city = new ArrayList<String>();

    List<String> ownerName = new ArrayList<String>();
    List<String> ownerSurname = new ArrayList<String>();
    List<String> wish = new ArrayList<String>();
    List<String> num = new ArrayList<String>();
    List<Integer> wish_id= new ArrayList<Integer>();
    List<Integer> state = new ArrayList<Integer>();
    List<Integer> commendCount = new ArrayList<Integer>();
    List<Integer> ownerId = new ArrayList<Integer>();
    List<String> usersPhoto = new ArrayList<String>();
    List<String> wishPhoto = new ArrayList<String>();

    SharedPreferences sPref;

    String responseRegion, responseCity, choisedRegion, choisedCity, responseWish;

    boolean used = false;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.fragment_statistic, container, false);

        rv = (RecyclerView) rootView.findViewById(R.id.rv);
        LinearLayoutManager llm = new LinearLayoutManager(getContext());
        rv.setLayoutManager(llm);

        spinnerRegion = (Spinner) rootView.findViewById(R.id.spinnerOfferRegion);
        spinnerCity = (Spinner) rootView.findViewById(R.id.spinnerOfferCity);

        sPref = this.getActivity().getSharedPreferences("APP", getActivity().MODE_PRIVATE);

        new getRegion().execute("");

        spinnerRegion.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                SharedPreferences.Editor ed = sPref.edit();
                ed.putString("statCountry1", spinnerRegion.getSelectedItem().toString());
                ed.apply();

                new getCity().execute("");
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spinnerCity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                SharedPreferences.Editor ed = sPref.edit();
                ed.putString("statCity1", spinnerCity.getSelectedItem().toString());
                ed.apply();

                getWishesInSelectedLocation();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        setHasOptionsMenu(true);

        return rootView;
    }



    class WishesConteiner {

        String wish;
        String name;
        String surname;
        String count;
        String imagePath;
        String wishphoto;
        int state;
        int wish_id;
        int commendCount;
        int ownerId;

        WishesConteiner(String wish, String name, String surname, String count, String imagePath, String wishphoto, int state, int wish_id,int commendCount, int reportCount) {
            this.wish = wish;
            this.name = name;
            this.surname = surname;
            this.count = count;
            this.imagePath = imagePath;
            this.wishphoto = wishphoto;
            this.state = state;
            this.wish_id = wish_id;
            this.commendCount = commendCount;
            this.ownerId = reportCount;
        }

    }

    private List<WishesConteiner> wishes;

    private void initializeData(){
        wishes = new ArrayList<>();
        rv.setAdapter(null);
        for (int i=0; i < ownerName.size(); i++)
            wishes.add(new WishesConteiner(wish.get(i), ownerName.get(i), ownerSurname.get(i), num.get(i), usersPhoto.get(i), wishPhoto.get(i), state.get(i), wish_id.get(i), commendCount.get(i), ownerId.get(i)));
    }

    public class RVAdapter extends RecyclerView.Adapter<RVAdapter.WishViewHolder> {

        List<WishesConteiner> wishes;
        public RVAdapter(List<WishesConteiner> wishes) {
            this.wishes = wishes;
        }

        @Override
        public WishViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.statistic_cardview_adapter, viewGroup, false);
            WishViewHolder wishViewHolder = new WishViewHolder(v);
            return wishViewHolder;
        }

        @Override
        public void onBindViewHolder(final WishViewHolder wishViewHolder, final int i) {
            wishViewHolder.wishTextView.setText(wishes.get(i).wish);
            wishViewHolder.ownerTextView.setText(wishes.get(i).name + "\n" + wishes.get(i).surname);
            wishViewHolder.countTextView.setText(wishes.get(i).count);
            wishViewHolder.commendCount.setText(String.valueOf(wishes.get(i).commendCount));

            try {
                if (!wishes.get(i).imagePath.equals(""))
                    Picasso.with(getActivity()).load(urlImage + wishes.get(i).imagePath).into(wishViewHolder.ownerImageView);
                else
                    wishViewHolder.ownerImageView.setImageResource(R.drawable.user);
            }
            catch (Exception e){
                Toast.makeText(getActivity(),getString(R.string.NoInternetConnection),Toast.LENGTH_SHORT).show();
            }
            try {
                if (!wishes.get(i).wishphoto.equals("") && !wishes.get(i).wishphoto.equals(null)) {
                    Picasso.with(getActivity()).load(urlImage + wishes.get(i).wishphoto).into(wishViewHolder.wishImageView);
                }
            }
            catch (Exception e){
                Toast.makeText(getActivity(),getString(R.string.NoInternetConnection),Toast.LENGTH_SHORT).show();
            }
            if (wishes.get(i).state == 1){
                wishViewHolder.likeImageView.setImageResource(R.drawable.shadedlike);
            }
            if (wishes.get(i).state == -1){
                wishViewHolder.dislikeImageView.setImageResource(R.drawable.shadeddislike);
            }
            if (wishes.get(i).state == 0) {
                wishViewHolder.likeImageView.setImageResource(R.drawable.like);
                wishViewHolder.dislikeImageView.setImageResource(R.drawable.dislike);
            }
            wishViewHolder.likeImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    choise = wishes.get(i).wish_id;
                    int count = Integer.parseInt(wishes.get(i).count);
                    if (wishes.get(i).state == 0) {
                        likeordislike = 1;
                        wishes.get(i).state = 1;
                        wishes.get(i).count = String.valueOf(count + 1);
                        wishViewHolder.likeImageView.setImageResource(R.drawable.shadedlike);
                        wishViewHolder.dislikeImageView.setImageResource(R.drawable.dislike);
                        wishViewHolder.countTextView.setText(String.valueOf(wishes.get(i).count));
                    } else if (wishes.get(i).state == -1) {
                        likeordislike = 1;
                        wishes.get(i).state = 1;
                        wishes.get(i).count = String.valueOf(count + 2);
                        wishViewHolder.likeImageView.setImageResource(R.drawable.shadedlike);
                        wishViewHolder.dislikeImageView.setImageResource(R.drawable.dislike);
                        wishViewHolder.countTextView.setText(String.valueOf(wishes.get(i).count));
                    } else if (wishes.get(i).state == 1) {
                        likeordislike = 0;
                        wishes.get(i).state = 0;
                        wishes.get(i).count = String.valueOf(count - 1);
                        wishViewHolder.countTextView.setText(String.valueOf(wishes.get(i).count));
                        wishViewHolder.likeImageView.setImageResource(R.drawable.like);
                        wishViewHolder.dislikeImageView.setImageResource(R.drawable.dislike);
                    }
                    try {
                        sendRateWish(i);
                    }
                    catch (Exception e){
                        Toast.makeText(getActivity(),getString(R.string.NoInternetConnection),Toast.LENGTH_SHORT).show();
                    }

                }
            });
            wishViewHolder.dislikeImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    choise = wishes.get(i).wish_id;
                    int count = Integer.parseInt(wishes.get(i).count);
                    if (wishes.get(i).state == 0) {
                        likeordislike = -1;
                        wishes.get(i).state = -1;
                        wishes.get(i).count = String.valueOf(count - 1);
                        wishViewHolder.likeImageView.setImageResource(R.drawable.like);
                        wishViewHolder.dislikeImageView.setImageResource(R.drawable.shadeddislike);
                        wishViewHolder.countTextView.setText(String.valueOf(wishes.get(i).count));
                    } else if (wishes.get(i).state == 1) {
                        likeordislike = -1;
                        wishes.get(i).state = -1;
                        wishes.get(i).count = String.valueOf(count - 2);
                        wishViewHolder.likeImageView.setImageResource(R.drawable.like);
                        wishViewHolder.dislikeImageView.setImageResource(R.drawable.shadeddislike);
                        wishViewHolder.countTextView.setText(String.valueOf(wishes.get(i).count));
                    } else if (wishes.get(i).state == -1) {
                        likeordislike = 0;
                        wishes.get(i).state = 0;
                        wishes.get(i).count = String.valueOf(count + 1);
                        wishViewHolder.countTextView.setText(String.valueOf(wishes.get(i).count));
                        wishViewHolder.likeImageView.setImageResource(R.drawable.like);
                        wishViewHolder.dislikeImageView.setImageResource(R.drawable.dislike);
                    }
                    try {
                        sendRateWish(i);
                    }
                    catch (Exception e){
                        Toast.makeText(getActivity(),getString(R.string.NoInternetConnection),Toast.LENGTH_SHORT).show();
                    }

                }
            });
            wishViewHolder.reportImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SharedPreferences.Editor ed = sPref.edit();
                    ed.putString("wish_id", String.valueOf(wishes.get(i).wish_id));
                    ed.apply();
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.replace(R.id.flContent, new ReportWishFragment(), "fragment_screen");
                    ft.addToBackStack(null);
                    ft.commit();
                }
            });
            wishViewHolder.shareImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent sendIntent = new Intent();
                    sendIntent.setAction(Intent.ACTION_SEND);
                    sendIntent.putExtra(Intent.EXTRA_TEXT, "Hey, check it!)) "+ "wpw.tmweb.ru/" +wishes.get(i).wish_id);
                    sendIntent.setType("text/plain");
                    startActivity(sendIntent);
                }
            });
            wishViewHolder.ownerTextView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    choise = wishes.get(i).ownerId;
                    if (choise != Integer.parseInt(sPref.getString("userId",""))) {
                        SharedPreferences.Editor ed = sPref.edit();
                        ed.putString("choise", String.valueOf(wishes.get(i).ownerId));
                        ed.putString("friend", "1");
                        ed.apply();
                        FragmentManager fm = getFragmentManager();
                        FragmentTransaction ft = fm.beginTransaction();
                        ft.replace(R.id.flContent, new NewUserPageFragment(), "fragment_screen");
                        ft.addToBackStack(null);
                        ft.commit();
                    }
                    else {
                        Toast.makeText(getActivity(),getString(R.string.ThisIsYou),Toast.LENGTH_SHORT).show();
                    }
                }
            });
            wishViewHolder.ownerImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    choise = wishes.get(i).ownerId;
                    if (choise != Integer.parseInt(sPref.getString("userId",""))) {
                        SharedPreferences.Editor ed = sPref.edit();
                        ed.putString("choise", String.valueOf(wishes.get(i).ownerId));
                        ed.putString("friend", "1");
                        ed.apply();
                        FragmentManager fm = getFragmentManager();
                        FragmentTransaction ft = fm.beginTransaction();
                        ft.replace(R.id.flContent, new NewUserPageFragment(), "fragment_screen");
                        ft.addToBackStack(null);
                        ft.commit();
                    }
                    else {
                        Toast.makeText(getActivity(),getString(R.string.ThisIsYou),Toast.LENGTH_SHORT).show();
                    }
                }
            });
            wishViewHolder.commendImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    choise = wishes.get(i).wish_id;
                    String a = String.valueOf(wishes.get(i).ownerId);
                    SharedPreferences.Editor ed = sPref.edit();
                    ed.putString("nameAndSurname", wishes.get(i).surname + " " + wishes.get(i).name);
                    ed.putString("wishText",wishes.get(i).wish);
                    ed.putString("choise", String.valueOf(choise));
                    ed.putString("user",a);
                    if (!wishes.get(i).imagePath.equals("")) {
                        ed.putString("userPage", wishes.get(i).imagePath);
                    }
                    ed.apply();
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.replace(R.id.flContent, new CommentFragment(), "fragment_screen");
                    ft.addToBackStack(null);
                    ft.commit();
                }
            });
            wishViewHolder.openOfferStatistic.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getActivity(), createOffer.class);
                    intent.putExtra("ch", "1");
                    intent.putExtra("wish_id", String.valueOf(wishes.get(i).wish_id));
                    startActivity(intent);
                }
            });

            wishViewHolder.wishImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getActivity(),OpenPhoto.class);
                    intent.putExtra("photo_path",urlImage+wishes.get(i).wishphoto);
                    startActivity(intent);
                }
            });

        }

        @Override
        public int getItemCount() {
            return wishes.size();
        }

        @Override
        public void onAttachedToRecyclerView(RecyclerView recyclerView) {
            super.onAttachedToRecyclerView(recyclerView);
        }

        public class WishViewHolder extends RecyclerView.ViewHolder {

            CardView cv;
            TextView wishTextView;
            TextView ownerTextView;
            TextView countTextView;
            TextView commendCount;
            ImageView likeImageView;
            ImageView dislikeImageView;
            ImageView shareImageView;
            ImageView reportImageView;
            ImageView commendImageView;
            ImageView openOfferStatistic;
            CircleImageView ownerImageView;
            ImageView wishImageView;
            WishViewHolder(View itemView) {
                super(itemView);
                cv = (CardView)itemView.findViewById(R.id.cv);
                wishTextView = (TextView)itemView.findViewById(R.id.wishTextView);
                ownerTextView = (TextView)itemView.findViewById(R.id.ownerTextView);
                countTextView = (TextView)itemView.findViewById(R.id.countTextView);
                likeImageView = (ImageView)itemView.findViewById(R.id.likeImageView);
                dislikeImageView = (ImageView)itemView.findViewById(R.id.dislikeImageView);
                shareImageView = (ImageView)itemView.findViewById(R.id.shareImageView);
                reportImageView = (ImageView)itemView.findViewById(R.id.reportImageView);
                commendImageView = (ImageView)itemView.findViewById(R.id.commendStatisticIamgeView);
                openOfferStatistic = (ImageView)itemView.findViewById(R.id.openOfferStatisticImageView);
                ownerImageView = (CircleImageView)itemView.findViewById(R.id.statisticUserPhotoImageView);
                wishImageView = (ImageView)itemView.findViewById(R.id.stasticWishImage);
                commendCount = (TextView)itemView.findViewById(R.id.commendCoundStatistc);
            }
        }
    }

    public void getWishesInSelectedLocation(){
        try {
            getWishes getwishes = new getWishes();
            getwishes.execute("");
        }
        catch (Exception e){

        }
    }

    private class getWishes extends AsyncTask<String, Void, Void> {

        ProgressDialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = ProgressDialog.show(getActivity(), "","", true, true);
        }

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code", "getWishesL");
            multipartEntity.addPart("country", sPref.getString("statCountry1",""));
            multipartEntity.addPart("city", sPref.getString("statCity1",""));
            multipartEntity.addPart("user_id", sPref.getString("userId", null));
            multipartEntity.addPart("lang", Locale.getDefault().getLanguage());


            httpPost.setEntity(multipartEntity);

            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                responseWish = EntityUtils.toString(entity);

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void o){
            super.onPostExecute(o);
            dialog.dismiss();
            if (responseWish != null) {
                try {
                    wishObject = new JSONObject(responseWish);
                    if (wishObject != null) {
                        wishArray = wishObject.getJSONArray("wishesInSelectedLocation");
                        ownerName = new ArrayList<String>();
                        ownerSurname = new ArrayList<String>();
                        wish = new ArrayList<String>();
                        num = new ArrayList<String>();
                        wishPhoto = new ArrayList<String>();
                        wish_id= new ArrayList<Integer>();
                        state = new ArrayList<Integer>();
                        commendCount = new ArrayList<Integer>();
                        ownerId = new ArrayList<Integer>();
                        usersPhoto = new ArrayList<String>();
                        for (int i = 0; i < wishArray.length(); i++) {
                            JSONObject catObj = (JSONObject) wishArray.get(i);
                            ownerName.add(catObj.getString("owner_name"));
                            ownerSurname.add(catObj.getString("owner_surname"));
                            wish.add(catObj.getString("wish_text"));
                            num.add(catObj.getString("count_likes"));
                            usersPhoto.add(catObj.getString("user_image_path"));
                            wishPhoto.add(catObj.getString("wish_image_path"));
                            wish_id.add(Integer.parseInt(catObj.getString("wish_id")));
                            state.add(Integer.parseInt(catObj.getString("state")));
                            commendCount.add(Integer.parseInt(catObj.getString("count_comments")));
                            ownerId.add(Integer.parseInt(catObj.getString("owner_id")));
                        }
                        if (ownerName.size() == 0){
                            Toast.makeText(getActivity(),getString(R.string.NoOneWishes),Toast.LENGTH_SHORT).show();
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                initializeData();
                RVAdapter adapter = new RVAdapter(wishes);
                rv.setAdapter(null);
                rv.setAdapter(adapter);
            }
        }
    }

    public void sendRateWish(int position){
        rateWish retewish = new rateWish();
        retewish.execute("");
    }

    private class rateWish extends AsyncTask<String, Void, Void> {
        private rateWish() {

        }

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();

            multipartEntity.addPart("code","ratewish");
            multipartEntity.addPart("user_id",sPref.getString("userId", null));
            multipartEntity.addPart("wish_id", String.valueOf(choise));
            multipartEntity.addPart("state", String.valueOf(likeordislike));


            httpPost.setEntity(multipartEntity);
            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                String response = EntityUtils.toString(entity);

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        public void onPostExecute(Void o){
            super.onPostExecute(o);
        }
    }

    private class getRegion extends AsyncTask<String, Void, Void> {
        ProgressDialog dialog;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = ProgressDialog.show(getActivity(),"",getString(R.string.Loading),true,true);
        }

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code","getCountry");
            multipartEntity.addPart("lang", Locale.getDefault().getLanguage());

            httpPost.setEntity(multipartEntity);

            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                responseRegion = EntityUtils.toString(entity);

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void o){
            super.onPostExecute(o);
            dialog.dismiss();
            Log.d("MYLOGS", responseRegion.toString());
            if (responseRegion != null) {
                try {
                    regionObject = new JSONObject(responseRegion);
                    if (regionObject != null) {
                        regionArray = regionObject.getJSONArray("countries");
                        for (int i = 0; i < regionArray.length(); i++) {
                            JSONObject catObj = (JSONObject) regionArray.get(i);
                            region.add(catObj.getString("country"));
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                try {
                    ArrayAdapter adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_dropdown_item, region);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinnerRegion.setAdapter(adapter);
                    new getCity().execute("");
                }
                catch (Exception e){

                }
            }
            else{
                dialog.dismiss();
                Toast.makeText(getActivity(), getString(R.string.NoInternetConnection),Toast.LENGTH_SHORT).show();
            }
        }
    }

    private class getCity extends AsyncTask<String, Void, Void> {
        ProgressDialog dialog;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = ProgressDialog.show(getActivity(),"", getString(R.string.Loading),true,true);
        }
        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code", "getCity");
            multipartEntity.addPart("country", spinnerRegion.getSelectedItem().toString());
            multipartEntity.addPart("lang",Locale.getDefault().getLanguage());

            httpPost.setEntity(multipartEntity);

            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                responseCity = EntityUtils.toString(entity);

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void o){
            super.onPostExecute(o);
            dialog.dismiss();
            if (responseCity != null) {
                try {
                    cityObject = new JSONObject(responseCity);
                    if (cityObject != null) {
                        city.clear();
                        cityArray = cityObject.getJSONArray("cities");
                        for (int i = 0; i < cityArray.length(); i++) {
                            JSONObject catObj = (JSONObject) cityArray.get(i);
                            city.add(catObj.getString("city"));
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            spinnerCity.setAdapter(null);
            ArrayAdapter adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_dropdown_item, city);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnerCity.setAdapter(adapter);
        }
    }



}
