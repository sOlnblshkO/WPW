package com.example.koyash.whatpeoplewant.MenuFragments;

import android.app.Dialog;
import android.support.v4.app.Fragment;
import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.koyash.whatpeoplewant.MultipartEntity;
import com.example.koyash.whatpeoplewant.R;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Created by koyash on 05.05.16.
 */
public class EditUsersInfoFragment extends Fragment implements View.OnClickListener {

    final String url = "http://wpw.tmweb.ru/API.php";

    EditText newname, newsurname, newpass, newemail;

    Spinner newcountry, newcity;

    Button change;

    String response;

    SharedPreferences sPref;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_edit, container,
                false);

        sPref = getActivity().getSharedPreferences("APP",getActivity().MODE_PRIVATE);

        newname = (EditText) view.findViewById(R.id.editTextName);
        newsurname = (EditText) view.findViewById(R.id.editTextSurname);
        newpass = (EditText) view.findViewById(R.id.editTextPass);
        newemail = (EditText) view.findViewById(R.id.editTextEmail);

        newcountry = (Spinner) view.findViewById(R.id.spinnerEditCountry);
        newcity = (Spinner) view.findViewById(R.id.spinnerEditCity);

        change = (Button) view.findViewById(R.id.ChangeBt);

        change.setOnClickListener(this);

        try {
            new uploadCountry().execute("");
        }
        catch (Exception e){
            Toast.makeText(getActivity(),getString(R.string.NoInternetConnection),Toast.LENGTH_SHORT).show();
        }

        newcountry.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                new uploadCity().execute("");

            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {

            }

        });

        newname.setText(sPref.getString("name",""));
        newsurname.setText(sPref.getString("surname",""));
        newemail.setText(sPref.getString("email",""));
        newpass.setText(sPref.getString("pass",""));

        return view;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.ChangeBt:
                abc();
                new changeInfo().execute("");
                break;
            default:
                break;
        }
    }

    JSONObject countrys;
    JSONArray countrys1;
    List<String> allcountrys = new ArrayList<String>();
    ArrayAdapter<String> adapter;

    public class uploadCountry extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code", "getCountry");
            multipartEntity.addPart("lang", Locale.getDefault().getLanguage());

            httpPost.setEntity(multipartEntity);

            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                response = EntityUtils.toString(entity);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            dialog = ProgressDialog.show(getActivity(), getString(R.string.Loading), getString(R.string.Country), true, true);
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Void o) {
            super.onPostExecute(o);

            dialog.dismiss();

            if (response != null) {
                try {
                    countrys = new JSONObject(response);
                    {
                        if (countrys != null) {
                            countrys1 = countrys.getJSONArray("countries");

                            for (int i = 0; i < countrys1.length(); i++) {
                                JSONObject catObj = (JSONObject) countrys1.get(i);
                                allcountrys.add(catObj.getString("country"));
                            }
                        }
                    }
                } catch (Exception e) {

                }
            }

            try {
                adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_dropdown_item, allcountrys);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                newcountry.setAdapter(adapter);
            } catch (Exception e) {
                Toast.makeText(getActivity(), getString(R.string.NoInternetConnection), Toast.LENGTH_SHORT).show();
            }

        }

    }

    JSONObject citys;
    JSONArray citys1;
    List<String> allcitys = new ArrayList<String>();
    String s, snewname , snewsurname ,snewpass , snewemail ,snewcountry, snewcity;

    private class uploadCity extends AsyncTask<String, Void, Void> {
        private uploadCity() {

        }

        ProgressDialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            s = newcountry.getSelectedItem().toString();
            dialog = ProgressDialog.show(getActivity(),getString(R.string.Loading),getString(R.string.City),true,true);
        }

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code", "getCity");
            multipartEntity.addPart("country", s);
            multipartEntity.addPart("lang", Locale.getDefault().getLanguage());
            httpPost.setEntity(multipartEntity);

            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                response = EntityUtils.toString(entity);
            } catch (IOException e) {
                Toast.makeText(getActivity(), "Sorry problems", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
            return null;
        }



        @Override
        protected void onPostExecute(Void o) {
            super.onPostExecute(o);
            dialog.dismiss();
            if (response != null) {
                try {
                    citys = new JSONObject(response);
                    if (citys != null) {
                        citys1 = citys.getJSONArray("cities");
                        allcitys.clear();
                        for (int i = 0; i < citys1.length(); i++) {
                            JSONObject catObj = (JSONObject) citys1.get(i);
                            allcitys.add(catObj.getString("city"));
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            try {
                newcity.setAdapter(null);
                adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_dropdown_item, allcitys);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                newcity.setAdapter(adapter);
            } catch (Exception e) {
                Toast.makeText(getActivity(), getString(R.string.NoInternetConnection), Toast.LENGTH_SHORT).show();
            }
        }
    }
    public void abc() {
        snewname = newname.getText().toString();
        snewsurname = newsurname.getText().toString();
        snewpass = newpass.getText().toString();
        snewcountry = newcountry.getSelectedItem().toString();
        snewcity = newcity.getSelectedItem().toString();
        snewemail = newemail.getText().toString();
    }
    private class changeInfo extends AsyncTask<String, Void, Void>{

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);

            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code","editUser");
            multipartEntity.addPart("user_id", sPref.getString("userId",""));
            multipartEntity.addPart("name",snewname);
            multipartEntity.addPart("surname",snewsurname);
            multipartEntity.addPart("password",snewpass);
            multipartEntity.addPart("email",snewemail);
            multipartEntity.addPart("country",snewcountry);
            multipartEntity.addPart("city",snewcity);

            httpPost.setEntity(multipartEntity);

            HttpResponse httpResponse = null;
            try{
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                response = EntityUtils.toString(entity);
            }
            catch (Exception e){

            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            Log.d("MYLOGS","responseEdit:" + response );
            if (response.equals("1")) {
                Toast.makeText(getActivity(),getString(R.string.chandegInfo),Toast.LENGTH_SHORT).show();
                SharedPreferences.Editor ed = sPref.edit();
                ed.putString("name",newname.getText().toString());
                ed.putString("surname",newsurname.getText().toString());
                ed.putString("city",newcity.getSelectedItem().toString());
                ed.putString("country",newcountry.getSelectedItem().toString());
                ed.putString("pass",newpass.getText().toString());
                ed.putString("email",newemail.getText().toString());
                ed.commit();
            }
        }
    }
}
