package com.example.koyash.whatpeoplewant.MenuFragments;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.koyash.whatpeoplewant.LoginAndSignUp.Menu;
import com.example.koyash.whatpeoplewant.MultipartEntity;
import com.example.koyash.whatpeoplewant.R;
import com.example.koyash.whatpeoplewant.NewUserPageFragment;
import com.squareup.picasso.Picasso;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;

public class MyFriendFragment extends Fragment implements View.OnClickListener {

    private static final String url = "http://wpw.tmweb.ru/API.php";
    final String urlImage = "http://wpw.tmweb.ru/";

    RecyclerView rv;

    JSONObject friendObject, newUserObject;

    JSONArray friendArray;

    List<String> ownerName = new ArrayList<String>();
    List<String> ownerSurname = new ArrayList<String>();
    List<String> country= new ArrayList<String>();
    List<String> city = new ArrayList<String>();
    List<String> friendId = new ArrayList<String>();
    List<String> friendsPhoto = new ArrayList<String>();

    Context context;

    SharedPreferences sPref;

    String response, responseGettedUser;

    int choise;

    Toolbar toolbar;

    TextView haveFriend;

    View view;

    ProgressBar progressBar;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_my_friend_fragment, container, false);

        rv = (RecyclerView) view.findViewById(R.id.rv);
        LinearLayoutManager llm = new LinearLayoutManager(getContext());
        rv.setLayoutManager(llm);

        progressBar = (ProgressBar) view.findViewById(R.id.myFriendProgressbar);

        sPref = this.getActivity().getSharedPreferences("APP", getActivity().MODE_PRIVATE);

        haveFriend = (TextView) view.findViewById(R.id.friendsTextView);

        haveFriend.setText(" ");

        setHasOptionsMenu(true);

        getFriend();

        return view;
    }

    final int MENU_ID = 1;

    @Override
    public void onCreateOptionsMenu(android.view.Menu menu, MenuInflater inflater) {
        menu.add(0,MENU_ID,0,"add").setIcon(R.drawable.abc_ic_search_api_material).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);

        MenuItem item = menu.getItem(0);
        final SearchView searchView = new SearchView(((Menu) getActivity()).getSupportActionBar().getThemedContext());
        MenuItemCompat.setShowAsAction(item, MenuItemCompat.SHOW_AS_ACTION_COLLAPSE_ACTION_VIEW | MenuItemCompat.SHOW_AS_ACTION_IF_ROOM);
        MenuItemCompat.setActionView(item, searchView);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                if (query.length()>0) {
                    findFriend(query);
                    progressBar.setVisibility(View.VISIBLE);
                }
                else{
                    getFriend();
                }
                return false;
            }
            @Override
            public boolean onQueryTextChange(String newText) {
                if (newText.length()>0) {
                    rv.setAdapter(null);
                    findFriend(newText);
                    progressBar.setVisibility(View.VISIBLE);
                }
                else{
                    getFriend();
                }
                return false;
            }
        });
        searchView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (searchView.getQuery().length()>0) {
                    findFriend(searchView.toString());
                    progressBar.setVisibility(View.VISIBLE);
                }
                else{
                    getFriend();
                }
            }
        });

        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case MENU_ID:

                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){

            default:
                break;
        }
    }

    class FriendInfoConteiner {

        String name;
        String surname;
        String country;
        String city;
        String friendId;
        String friendPhoto;

        FriendInfoConteiner(String name, String surname, String country, String city, String friendId, String friendPhoto) {
            this.name = name;
            this.surname = surname;
            this.country = country;
            this.city = city;
            this.friendId = friendId;
            this.friendPhoto = friendPhoto;
        }
    }

    private List<FriendInfoConteiner> friends;

    private void initializeData() {
        friends = new ArrayList<>();
        rv.setAdapter(null);
        if (ownerName.size() > 0) {
            haveFriend.setText("");
            for (int i = 0; i < ownerName.size(); i++)
                friends.add(new FriendInfoConteiner(ownerName.get(i), ownerSurname.get(i), country.get(i), city.get(i), friendId.get(i), friendsPhoto.get(i)));
        }
    }

    public class RVAdapterFriend extends RecyclerView.Adapter<RVAdapterFriend.WishViewHolder> {

        List<FriendInfoConteiner> friends;
        public RVAdapterFriend(List<FriendInfoConteiner> friends) {
            this.friends = friends;
        }

        @Override
        public WishViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.friend_cardview_adapter, viewGroup, false);
            WishViewHolder wishViewHolder = new WishViewHolder(v);
            return wishViewHolder;
        }

        @Override
        public void onBindViewHolder(final WishViewHolder wishViewHolder, final int i) {

            wishViewHolder.starImageView.setVisibility(View.VISIBLE);
            wishViewHolder.starImageView.setEnabled(true);
            wishViewHolder.nameTextView.setText(friends.get(i).name);
            wishViewHolder.surnameTextView.setText(friends.get(i).surname);
            wishViewHolder.cityTextView.setText(friends.get(i).city);
            wishViewHolder.countryTextView.setText(friends.get(i).country);
            wishViewHolder.starImageView.setImageResource(R.drawable.shadedstar);
            if (!friends.get(i).friendPhoto.equals(""))
                Picasso.with(getActivity()).load(urlImage + friends.get(i).friendPhoto).into(wishViewHolder.friendImageView);
            else
                wishViewHolder.friendImageView.setImageResource(R.drawable.user);

            wishViewHolder.nameTextView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SharedPreferences.Editor ed = sPref.edit();
                    ed.putString("choise", friends.get(i).friendId);
                    ed.putString("friend", "1");
                    ed.apply();
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.replace(R.id.flContent, new NewUserPageFragment(),"frament_screen");
                    ft.addToBackStack(null);
                    ft.commit();
                }
            });
            wishViewHolder.surnameTextView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SharedPreferences.Editor ed = sPref.edit();
                    ed.putString("choise", friends.get(i).friendId);
                    ed.putString("friend", "1");
                    ed.apply();
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.replace(R.id.flContent, new NewUserPageFragment(),"frament_screen");
                    ft.addToBackStack(null);
                    ft.commit();
                }
            });
            wishViewHolder.countryTextView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SharedPreferences.Editor ed = sPref.edit();
                    ed.putString("choise", friends.get(i).friendId);
                    ed.putString("friend", "1");
                    ed.apply();
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.replace(R.id.flContent, new NewUserPageFragment(),"frament_screen");
                    ft.addToBackStack(null);
                    ft.commit();
                }
            });
            wishViewHolder.cityTextView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SharedPreferences.Editor ed = sPref.edit();
                    ed.putString("choise", friends.get(i).friendId);
                    ed.putString("friend", "1");
                    ed.apply();
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.replace(R.id.flContent, new NewUserPageFragment(),"frament_screen");
                    ft.addToBackStack(null);
                    ft.commit();
                }
            });
            wishViewHolder.friendImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SharedPreferences.Editor ed = sPref.edit();
                    ed.putString("choise", friends.get(i).friendId);
                    ed.putString("friend", "1");
                    ed.apply();
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.replace(R.id.flContent, new NewUserPageFragment(),"frament_screen");
                    ft.addToBackStack(null);
                    ft.commit();
                }
            });
            wishViewHolder.starImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog ad = new AlertDialog.Builder(getActivity())
                            .create();
                    ad.setCancelable(true);
                    ad.setTitle(getString(R.string.DeleteFromFriend));
                    ad.setMessage(getString(R.string.DeleteFromFriend1));
                    ad.setButton(getString(R.string.yes), new DialogInterface.OnClickListener() {

                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            choise = Integer.parseInt(friends.get(i).friendId);
                            deleteSelectedFriend();
                        }
                    });
                    ad.show();
                }
            });
        }

        @Override
        public int getItemCount() {
            return friends.size();
        }

        @Override
        public void onAttachedToRecyclerView(RecyclerView recyclerView) {
            super.onAttachedToRecyclerView(recyclerView);
        }

        public class WishViewHolder extends RecyclerView.ViewHolder {

            CardView cv;
            TextView nameTextView;
            TextView surnameTextView;
            TextView cityTextView;
            TextView countryTextView;
            CircleImageView friendImageView;
            ImageView starImageView;
            WishViewHolder(View itemView) {
                super(itemView);
                cv = (CardView)itemView.findViewById(R.id.cv);
                nameTextView = (TextView)itemView.findViewById(R.id.friendName);
                surnameTextView = (TextView)itemView.findViewById(R.id.friendSurname);
                cityTextView = (TextView)itemView.findViewById(R.id.friendCity);
                countryTextView = (TextView)itemView.findViewById(R.id.friendCountry);
                friendImageView = (CircleImageView) itemView.findViewById(R.id.friendIamgeView);
                starImageView = (ImageView)itemView.findViewById(R.id.friendImageView123);
            }
        }

    }

    public class RVAdapterFindedFriend extends RecyclerView.Adapter<RVAdapterFindedFriend.WishViewHolder> {

        List<FriendInfoConteiner> friends;
        public RVAdapterFindedFriend(List<FriendInfoConteiner> friends) {
            this.friends = friends;
        }

        @Override
        public WishViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.friend_cardview_adapter, viewGroup, false);
            WishViewHolder wishViewHolder = new WishViewHolder(v);
            return wishViewHolder;
        }

        @Override
        public void onBindViewHolder(final WishViewHolder wishViewHolder, final int i) {

            wishViewHolder.nameTextView.setText(friends.get(i).name);
            wishViewHolder.surnameTextView.setText(friends.get(i).surname);
            wishViewHolder.cityTextView.setText(friends.get(i).city);
            wishViewHolder.countryTextView.setText(friends.get(i).country);
            wishViewHolder.starImageView.setVisibility(View.INVISIBLE);
            wishViewHolder.starImageView.setEnabled(false);

            if (!friends.get(i).friendPhoto.equals(""))
                Picasso.with(getActivity()).load(urlImage + friends.get(i).friendPhoto).into(wishViewHolder.friendImageView);
            else
                wishViewHolder.friendImageView.setImageResource(R.drawable.user);

            wishViewHolder.nameTextView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    choise = Integer.parseInt(friends.get(i).friendId);
                    if (sPref.getString("userId","") != String.valueOf(choise)) {
                        Intent intent = new Intent(getActivity(), NewUserPageFragment.class);
                        intent.putExtra("choise", friends.get(i).friendId);
                        startActivity(intent);
                    }
                    else{
                        Toast.makeText(getActivity(),getString(R.string.ThisIsYou),Toast.LENGTH_SHORT).show();
                    }
                }
            });
            wishViewHolder.surnameTextView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    choise = Integer.parseInt(friends.get(i).friendId);
                    if (sPref.getString("userId","") != String.valueOf(choise)) {
                        Intent intent = new Intent(getActivity(), NewUserPageFragment.class);
                        intent.putExtra("choise", friends.get(i).friendId);
                        startActivity(intent);
                    }
                    else{
                        Toast.makeText(getActivity(),getString(R.string.ThisIsYou),Toast.LENGTH_SHORT).show();
                    }
                }
            });
            wishViewHolder.countryTextView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    choise = Integer.parseInt(friends.get(i).friendId);
                    if (sPref.getString("userId","") != String.valueOf(choise)) {
                        Intent intent = new Intent(getActivity(), NewUserPageFragment.class);
                        intent.putExtra("choise", friends.get(i).friendId);
                        startActivity(intent);
                    }
                    else{
                        Toast.makeText(getActivity(),getString(R.string.ThisIsYou),Toast.LENGTH_SHORT).show();
                    }
                }
            });
            wishViewHolder.cityTextView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    choise = Integer.parseInt(friends.get(i).friendId);
                    if (sPref.getString("userId","") != String.valueOf(choise)) {
                        Intent intent = new Intent(getActivity(), NewUserPageFragment.class);
                        intent.putExtra("choise", friends.get(i).friendId);
                        startActivity(intent);
                    }
                    else{
                        Toast.makeText(getActivity(),getString(R.string.ThisIsYou),Toast.LENGTH_SHORT).show();
                    }
                }
            });
            wishViewHolder.friendImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    choise = Integer.parseInt(friends.get(i).friendId);
                    if (sPref.getString("userId","") != String.valueOf(choise)) {
                        Intent intent = new Intent(getActivity(), NewUserPageFragment.class);
                        intent.putExtra("choise", friends.get(i).friendId);
                        startActivity(intent);
                    }
                    else{
                        Toast.makeText(getActivity(),getString(R.string.ThisIsYou),Toast.LENGTH_SHORT).show();
                    }
                }
            });
            wishViewHolder.starImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog ad = new AlertDialog.Builder(getActivity() )
                            .create();
                    ad.setCancelable(true);
                    ad.setTitle(getString(R.string.DeleteFromFriend));
                    ad.setMessage(getString(R.string.DeleteFromFriend1));
                    ad.setButton(getString(R.string.yes), new DialogInterface.OnClickListener() {

                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            choise = Integer.parseInt(friends.get(i).friendId);
                            deleteSelectedFriend();
                        }
                    });
                    ad.show();
                }
            });
        }

        @Override
        public int getItemCount() {
            return friends.size();
        }

        @Override
        public void onAttachedToRecyclerView(RecyclerView recyclerView) {
            super.onAttachedToRecyclerView(recyclerView);
        }

        public class WishViewHolder extends RecyclerView.ViewHolder {

            CardView cv;
            TextView nameTextView;
            TextView surnameTextView;
            TextView cityTextView;
            TextView countryTextView;
            CircleImageView friendImageView;
            ImageView starImageView;
            WishViewHolder(View itemView) {
                super(itemView);
                cv = (CardView)itemView.findViewById(R.id.cv);
                nameTextView = (TextView)itemView.findViewById(R.id.friendName);
                surnameTextView = (TextView)itemView.findViewById(R.id.friendSurname);
                cityTextView = (TextView)itemView.findViewById(R.id.friendCity);
                countryTextView = (TextView)itemView.findViewById(R.id.friendCountry);
                friendImageView = (CircleImageView) itemView.findViewById(R.id.friendIamgeView);
                starImageView = (ImageView)itemView.findViewById(R.id.friendImageView123);
            }
        }

    }

    public void getFriend(){
        getFriends getfriends = new getFriends();
        getfriends.execute("");
    }

    private class getFriends extends AsyncTask<String, Void, Void> {

        ProgressDialog dialog;

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code","getFriends");
            multipartEntity.addPart("user_id",sPref.getString("userId",null));
            multipartEntity.addPart("lang", Locale.getDefault().getLanguage());

            httpPost.setEntity(multipartEntity);

            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                response= EntityUtils.toString(entity);

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            haveFriend.setText("");
        }

        @Override
        protected void onPostExecute(Void o){
            super.onPostExecute(o);
            Log.d("MYLOGS","friends response: " + response);
            if (response != null){
                try {
                    friendObject = new JSONObject(response);
                    friendArray = friendObject.getJSONArray("friends");
                    ownerName = new ArrayList<String>();
                    ownerSurname = new ArrayList<String>();
                    country = new ArrayList<String>();
                    city = new ArrayList<String>();
                    friendId = new ArrayList<String>();
                    friendsPhoto = new ArrayList<String>();
                    for (int i=0; i < friendArray.length(); i++){
                        JSONObject catObj = (JSONObject) friendArray.get(i);
                        ownerName.add(catObj.getString("name"));
                        ownerSurname.add(catObj.getString("surname"));
                        country.add(catObj.getString("country"));
                        city.add(catObj.getString("city"));
                        friendId.add(catObj.getString("user_id"));
                        friendsPhoto.add(catObj.getString("image_path"));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            if (friendObject == null){
                haveFriend.setText(getString(R.string.NoInternetConnection));
            }
            else if (friendObject.length() == 0){
                haveFriend.setText(getString(R.string.NoFriends));
            }
            progressBar.setVisibility(View.INVISIBLE);
            initializeData();
            RVAdapterFriend adapter = new RVAdapterFriend(friends);
            rv.setAdapter(null);
            rv.setAdapter(adapter);
        }
    }

    String code , id ,name , surname , ncountry , ncity ,friend, image_path;

    public void abc(){

        try {
            name = newUserObject.getString("name");
            surname = newUserObject.getString("surname");
            ncity = newUserObject.getString("city");
            ncountry = newUserObject.getString("country");
            id = newUserObject.getString("id");
            code = newUserObject.getString("code");
            image_path = newUserObject.getString("image_path");
            friend = "1";
        } catch (JSONException e) {

        }

    }

    public void deleteSelectedFriend(){
        deleteFriend deletefriend = new deleteFriend();
        deletefriend.execute("");
    }

    private class deleteFriend extends AsyncTask<String, Void, Void> {

        ProgressDialog dialog;

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code","addFriend");
            multipartEntity.addPart("user_id",sPref.getString("userId",null));
            multipartEntity.addPart("friend_id", String.valueOf(choise));

            httpPost.setEntity(multipartEntity);
            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                response = EntityUtils.toString(entity);

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = ProgressDialog.show(getActivity(),"Loading","Deleting friend",true ,false);
        }

        @Override
        public void onPostExecute(Void o){
            super.onPostExecute(o);
            dialog.dismiss();
            if (response.equals("1")){
                getFriend();
            }
        }
    }

    String newuser;

    public void findFriend(String user){
        newuser = user;
        new findFriends().execute("");
    }

    private class findFriends extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code","findFriends");
            multipartEntity.addPart("user", newuser);
            multipartEntity.addPart("lang", Locale.getDefault().getLanguage());

            httpPost.setEntity(multipartEntity);

            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                response= EntityUtils.toString(entity);

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            haveFriend.setText("");
        }

        @Override
        protected void onPostExecute(Void o){
            super.onPostExecute(o);
            Log.d("MYLOGS", "finded response: " + response);
            if (response != null){
                try {
                    friendObject = new JSONObject(response);
                    friendArray = friendObject.getJSONArray("friends");
                    ownerName = new ArrayList<String>();
                    ownerSurname = new ArrayList<String>();
                    country = new ArrayList<String>();
                    city = new ArrayList<String>();
                    friendId = new ArrayList<String>();
                    friendsPhoto = new ArrayList<String>();
                    for (int i=0; i < friendArray.length(); i++){
                        JSONObject catObj = (JSONObject) friendArray.get(i);
                        ownerName.add(catObj.getString("name"));
                        ownerSurname.add(catObj.getString("surname"));
                        country.add(catObj.getString("country"));
                        city.add(catObj.getString("city"));
                        friendId.add(catObj.getString("user_id"));
                        friendsPhoto.add(catObj.getString("image_path"));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            if (ownerName.size() == 0){
                Log.d("MYLOGS","asdadaad");
                haveFriend.setText(getString(R.string.FriendRequset));
                progressBar.setVisibility(View.INVISIBLE);
            }
            progressBar.setVisibility(View.INVISIBLE);
            initializeData();
            RVAdapterFindedFriend adapter = new RVAdapterFindedFriend(friends);
            rv.setAdapter(null);
            rv.setAdapter(adapter);

        }
    }

    @Override
    public void onResume() {
        super.onResume();
        getFriend();
    }
}
