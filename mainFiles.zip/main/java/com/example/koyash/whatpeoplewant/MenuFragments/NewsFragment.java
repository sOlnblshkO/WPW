package com.example.koyash.whatpeoplewant.MenuFragments;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.koyash.whatpeoplewant.MultipartEntity;
import com.example.koyash.whatpeoplewant.R;
import com.example.koyash.whatpeoplewant.NewUserPageFragment;
import com.squareup.picasso.Picasso;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;


public class NewsFragment extends Fragment {

    private static final String url = "http://wpw.tmweb.ru/API.php";
    final String urlImage = "http://wpw.tmweb.ru/";

    RecyclerView rv;

    JSONObject newsObject,newUserObject;

    JSONArray newsArray;

    String response,choiseofOwner,responseGettedUser;

    List<String> ownerId = new ArrayList<String>();
    List<String> ownerName = new ArrayList<String>();
    List<String> ownerSurname = new ArrayList<String>();
    List<String> newsTitle = new ArrayList<String>();
    List<String> newsText = new ArrayList<String>();
    List<String> date = new ArrayList<String>();
    List<String> ownerImage = new ArrayList<String>();

    SharedPreferences sPref;

    ProgressBar progressBar;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootview = inflater.inflate(R.layout.fragment_news, container, false);

        rv = (RecyclerView) rootview.findViewById(R.id.rv);
        LinearLayoutManager llm = new LinearLayoutManager(getContext());
        rv.setLayoutManager(llm);

        sPref = this.getActivity().getSharedPreferences("APP", getActivity().MODE_PRIVATE);

        progressBar = (ProgressBar)rootview.findViewById(R.id.progressBar);

        getNews1();

        return rootview;
    }

    class newsConteiner {

        String id;
        String name;
        String surname;
        String date;
        String newsTitle;
        String newsText;
        String ownerImage;

        newsConteiner(String id, String name, String surname, String date, String newsTitle, String newsText,String ownerImage) {
            this.id = id;
            this.name = name;
            this.surname = surname;
            this.date = date;
            this.newsTitle = newsTitle;
            this.newsText = newsText;
            this.ownerImage = ownerImage;
        }

    }
    private List<newsConteiner> news;

    private void initializeData(){
        news = new ArrayList<>();
        for (int i=0;i<ownerName.size();i++)
            news.add(new newsConteiner(ownerId.get(i), ownerName.get(i), ownerSurname.get(i), date.get(i), newsTitle.get(i), newsText.get(i),ownerImage.get(i)));
    }

    public class RVAdapter extends RecyclerView.Adapter<RVAdapter.WishViewHolder> {

        List<newsConteiner> wishes;

        public RVAdapter(List<newsConteiner> wishes) {
            this.wishes = wishes;
        }

        @Override
        public WishViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.news_card_view_adapter, viewGroup, false);
            WishViewHolder wishViewHolder = new WishViewHolder(v);
            return wishViewHolder;
        }

        @Override
        public void onBindViewHolder(final WishViewHolder wishViewHolder, final int i) {
            wishViewHolder.nameTextView.setText(wishes.get(i).name);
            wishViewHolder.surnameTextView.setText(wishes.get(i).surname);
            wishViewHolder.dateTextView.setText(wishes.get(i).date);
            wishViewHolder.titleTextView.setText(wishes.get(i).newsTitle);
            wishViewHolder.textTextView.setText(wishes.get(i).newsText);
            if (!wishes.get(i).ownerImage.equals(""))
                try {
                    Picasso.with(getActivity()).load(urlImage + wishes.get(i).ownerImage).into(wishViewHolder.ownersImage);
                } catch (Exception e) {
                    wishViewHolder.ownersImage.setImageResource(R.drawable.user);
                }

            wishViewHolder.nameTextView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    choiseofOwner = wishes.get(i).id;
                    if (!choiseofOwner.equals(Integer.parseInt(sPref.getString("userId", "")))) {
                        SharedPreferences.Editor ed = sPref.edit();
                        ed.putString("choise", String.valueOf(wishes.get(i).id));
                        ed.putString("friend", "1");
                        ed.apply();
                        FragmentManager fm = getFragmentManager();
                        FragmentTransaction ft = fm.beginTransaction();
                        ft.replace(R.id.flContent, new NewUserPageFragment(), "fragment_screen");
                        ft.addToBackStack(null);
                        ft.commit();
                    } else {
                        Toast.makeText(getActivity(), getString(R.string.ThisIsYou), Toast.LENGTH_SHORT).show();
                    }
                }
            });
            wishViewHolder.surnameTextView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    choiseofOwner = wishes.get(i).id;
                    if (!choiseofOwner.equals(Integer.parseInt(sPref.getString("userId", "")))) {
                        SharedPreferences.Editor ed = sPref.edit();
                        ed.putString("choise", String.valueOf(wishes.get(i).id));
                        ed.putString("friend", "1");
                        ed.apply();
                        FragmentManager fm = getFragmentManager();
                        FragmentTransaction ft = fm.beginTransaction();
                        ft.replace(R.id.flContent, new NewUserPageFragment(), "fragment_screen");
                        ft.addToBackStack(null);
                        ft.commit();
                    } else {
                        Toast.makeText(getActivity(), getString(R.string.ThisIsYou), Toast.LENGTH_SHORT).show();
                    }
                }
            });
            wishViewHolder.ownersImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    choiseofOwner = wishes.get(i).id;
                    if (!choiseofOwner.equals(Integer.parseInt(sPref.getString("userId", "")))) {
                        SharedPreferences.Editor ed = sPref.edit();
                        ed.putString("choise", String.valueOf(wishes.get(i).id));
                        ed.putString("friend", "1");
                        ed.apply();
                        FragmentManager fm = getFragmentManager();
                        FragmentTransaction ft = fm.beginTransaction();
                        ft.replace(R.id.flContent, new NewUserPageFragment(), "fragment_screen");
                        ft.addToBackStack(null);
                        ft.commit();
                    } else {
                        Toast.makeText(getActivity(), getString(R.string.ThisIsYou), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        @Override
        public int getItemCount() {
            return wishes.size();
        }

        @Override
        public void onAttachedToRecyclerView(RecyclerView recyclerView) {
            super.onAttachedToRecyclerView(recyclerView);
        }

        public class WishViewHolder extends RecyclerView.ViewHolder {

            CardView cv;
            TextView nameTextView, surnameTextView, dateTextView, titleTextView, textTextView;
            CircleImageView ownersImage;

            WishViewHolder(View itemView) {
                super(itemView);
                cv = (CardView) itemView.findViewById(R.id.cv);
                nameTextView = (TextView) itemView.findViewById(R.id.nameTextView);
                surnameTextView = (TextView) itemView.findViewById(R.id.surnameTextView);
                dateTextView = (TextView) itemView.findViewById(R.id.dateTextView);
                titleTextView = (TextView) itemView.findViewById(R.id.tilteTextView);
                textTextView = (TextView) itemView.findViewById(R.id.textTextView);
                ownersImage = (CircleImageView) itemView.findViewById(R.id.newsOwnersImage);
            }
        }

    }

    public void getNews1(){
        getNews getnews = new getNews();
        getnews.execute("");
    }

    private class getNews extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code","showNews");
            multipartEntity.addPart("user_id",sPref.getString("userId",null));
            multipartEntity.addPart("lang",Locale.getDefault().getLanguage());

            httpPost.setEntity(multipartEntity);

            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                response = EntityUtils.toString(entity);

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void o) {
            super.onPostExecute(o);
            if (response != null) {
                try {
                    newsObject = new JSONObject(response);
                    if (newsObject != null) {
                        newsArray = newsObject.getJSONArray("news");
                        ownerId = new ArrayList<String>();
                        ownerName = new ArrayList<String>();
                        ownerSurname = new ArrayList<String>();
                        newsTitle = new ArrayList<String>();
                        newsText = new ArrayList<String>();
                        date = new ArrayList<String>();
                        ownerImage = new ArrayList<String>();
                        for (int i = 0; i < newsArray.length(); i++) {
                            JSONObject catObj = (JSONObject) newsArray.get(i);
                            ownerId.add(catObj.getString("user_id"));
                            ownerName.add(catObj.getString("name"));
                            ownerSurname.add(catObj.getString("surname"));
                            newsTitle.add(catObj.getString("news_title"));
                            newsText.add(catObj.getString("news_text"));
                            date.add(catObj.getString("creation_date"));
                            ownerImage.add(catObj.getString("image_path"));
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                try {
                    getActivity().findViewById(R.id.loadingPanelNews).setVisibility(View.GONE);
                    initializeData();
                    RVAdapter adapter = new RVAdapter(news);
                    rv.setAdapter(null);
                    rv.setAdapter(adapter);
                } catch (Exception e) {

                }
            } else {
                Toast.makeText(getActivity(), "No Internet Connection", Toast.LENGTH_SHORT).show();
                getActivity().findViewById(R.id.loadingPanelNews).setVisibility(View.GONE);
            }
        }
    }

}
