package com.example.koyash.whatpeoplewant;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class NewUserPageFragment extends Fragment implements View.OnClickListener {

    private final static String url = "http://wpw.tmweb.ru/API.php";
    final String urlImage = "http://wpw.tmweb.ru/";

    boolean isImageFitToScreen;

    String responseGettedInfo, response,responseaddedtofriend;

    int choise, likeordislike = 0;

    JSONObject gettedInfo;

    JSONObject wishObject;
    JSONArray wishArray;
    List<String> wish = new ArrayList<String>();
    List<String> num = new ArrayList<String>();
    List<String> wish_image = new ArrayList<String>();
    List<Integer> wish_id = new ArrayList<Integer>();
    List<Integer> state = new ArrayList<Integer>();
    List<Integer> apllied = new ArrayList<Integer>();
    List<Integer> commendCount = new ArrayList<Integer>();

    SharedPreferences sPref;

    CollapsingToolbarLayout toolbar;

    TextView cityandcountry, userswishes;

    ImageView backgroundImage;

    Button addtofrind;

    RecyclerView rv;

    View view;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.activity_new_user_page2, container,
                false);

        sPref = getActivity().getSharedPreferences("APP", getActivity().MODE_PRIVATE);

        rv = (RecyclerView) view.findViewById(R.id.rvNewUserPage);
        LinearLayoutManager llm;
        llm = new LinearLayoutManager(getContext());
        rv.setLayoutManager(llm);

        addtofrind = (Button) view.findViewById(R.id.addToFriendButton);

        addtofrind.setOnClickListener(this);

        toolbar = (CollapsingToolbarLayout) view.findViewById(R.id.toolbar_layout_new_user_page);

        cityandcountry = (TextView) view.findViewById(R.id.cityAndCountryNewUser);

        userswishes = (TextView) view.findViewById(R.id.textView22);

        backgroundImage = (ImageView) view.findViewById(R.id.backgroundNewUserImageView);

        backgroundImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!getImage.equals("") && !getImage.equals(null)) {
                    Intent intentPhoto = new Intent(getActivity(), OpenPhoto.class);
                    intentPhoto.putExtra("photo_path", urlImage + getImage);
                    startActivity(intentPhoto);
                }
            }
        });

        new getUserInfo().execute("");

        new usersWish().execute("");

        return view;

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.addToFriendButton:
                if (getFriend.equals("1")) {
                    getFriend = "0";
                    addtofrind.setText(getString(R.string.AddToFriend));
                }
                else{
                    getFriend = "1";
                    addtofrind.setText(getString(R.string.DeleteFromFriend));
                }
                new addToFriend().execute("");
                break;
            default:
                break;
        }
    }

    class WishesConteiner {

        String count;
        String wish_image;
        String wish;
        int wish_id;
        int state;
        int aplied;
        int commendCount;

        WishesConteiner(String wish, String count, String wish_image, int wish_id, int state, int aplied, int commendCount) {
            this.wish = wish;
            this.count = count;
            this.wish_image = wish_image;
            this.wish_id = wish_id;
            this.state = state;
            this.aplied = aplied;
            this.commendCount = commendCount;
        }

    }

    private List<WishesConteiner> wishes;

    private void initializeData() {
        wishes = new ArrayList<>();
        rv.setAdapter(null);
        if (wish.size() > 0) {
            for (int i = 0; i < wish.size(); i++) {
                wishes.add(new WishesConteiner(wish.get(i), num.get(i), wish_image.get(i), wish_id.get(i), state.get(i), apllied.get(i), commendCount.get(i)));
            }
        }
        else{
            rv.setAdapter(null);
            userswishes.setText(getString(R.string.noWishesUser));
        }
    }

    public class RVAdapter extends RecyclerView.Adapter<RVAdapter.WishViewHolder> {

        List<WishesConteiner> wishes;

        public RVAdapter(List<WishesConteiner> wishes) {
            this.wishes = wishes;
        }

        @Override
        public WishViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.new_user_page_adapter, viewGroup, false);
            WishViewHolder wishViewHolder = new WishViewHolder(v);
            return wishViewHolder;
        }

        @Override
        public void onBindViewHolder(final NewUserPageFragment.RVAdapter.WishViewHolder wishViewHolder, final int i) {
            wishViewHolder.wishTextView.setText(wishes.get(i).wish);
            wishViewHolder.countTextView.setText(wishes.get(i).count);
            wishViewHolder.commendCount.setText(String.valueOf(wishes.get(i).commendCount));
            if (!wishes.get(i).wish_image.equals(null) || !wishes.get(i).wish_image.equals("Uploads/")) {
                Picasso.with(getActivity()).load(urlImage + wishes.get(i).wish_image).into(wishViewHolder.wishImageView);
            }
            if (wishes.get(i).state == 1) {
                wishViewHolder.likeImageView.setImageResource(R.drawable.shadedlike);
            }
            if (wishes.get(i).state == -1) {
                wishViewHolder.dislikeImageView.setImageResource(R.drawable.shadeddislike);
            }
            if (wishes.get(i).state == 0) {
                wishViewHolder.likeImageView.setImageResource(R.drawable.like);
                wishViewHolder.dislikeImageView.setImageResource(R.drawable.dislike);
            }

            wishViewHolder.likeImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    choise = wishes.get(i).wish_id;
                    int count = Integer.parseInt(wishes.get(i).count);
                    if (wishes.get(i).state == 0) {
                        likeordislike = 1;
                        wishes.get(i).state = 1;
                        wishes.get(i).count = String.valueOf(count + 1);
                        wishViewHolder.likeImageView.setImageResource(R.drawable.shadedlike);
                        wishViewHolder.dislikeImageView.setImageResource(R.drawable.dislike);
                        wishViewHolder.countTextView.setText(String.valueOf(wishes.get(i).count));
                    } else if (wishes.get(i).state == -1) {
                        likeordislike = 1;
                        wishes.get(i).state = 1;
                        wishes.get(i).count = String.valueOf(count + 2);
                        wishViewHolder.likeImageView.setImageResource(R.drawable.shadedlike);
                        wishViewHolder.dislikeImageView.setImageResource(R.drawable.dislike);
                        wishViewHolder.countTextView.setText(String.valueOf(wishes.get(i).count));
                    } else if (wishes.get(i).state == 1) {
                        likeordislike = 0;
                        wishes.get(i).state = 0;
                        wishes.get(i).count = String.valueOf(count - 1);
                        wishViewHolder.countTextView.setText(String.valueOf(wishes.get(i).count));
                        wishViewHolder.likeImageView.setImageResource(R.drawable.like);
                        wishViewHolder.dislikeImageView.setImageResource(R.drawable.dislike);
                    }
                    try {
                        new rateWish().execute("");
                    } catch (Exception e) {
                        Toast.makeText(getActivity(), getString(R.string.NoInternetConnection), Toast.LENGTH_SHORT).show();
                    }
                }
            });
            wishViewHolder.dislikeImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    choise = wishes.get(i).wish_id;
                    int count = Integer.parseInt(wishes.get(i).count);
                    if (wishes.get(i).state == 0) {
                        likeordislike = -1;
                        wishes.get(i).state = -1;
                        wishes.get(i).count = String.valueOf(count - 1);
                        wishViewHolder.likeImageView.setImageResource(R.drawable.like);
                        wishViewHolder.dislikeImageView.setImageResource(R.drawable.shadeddislike);
                        wishViewHolder.countTextView.setText(String.valueOf(wishes.get(i).count));
                    } else if (wishes.get(i).state == 1) {
                        likeordislike = -1;
                        wishes.get(i).state = -1;
                        wishes.get(i).count = String.valueOf(count - 2);
                        wishViewHolder.likeImageView.setImageResource(R.drawable.like);
                        wishViewHolder.dislikeImageView.setImageResource(R.drawable.shadeddislike);
                        wishViewHolder.countTextView.setText(String.valueOf(wishes.get(i).count));
                    } else if (wishes.get(i).state == -1) {
                        likeordislike = 0;
                        wishes.get(i).state = 0;
                        wishes.get(i).count = String.valueOf(count + 1);
                        wishViewHolder.countTextView.setText(String.valueOf(wishes.get(i).count));
                        wishViewHolder.likeImageView.setImageResource(R.drawable.like);
                        wishViewHolder.dislikeImageView.setImageResource(R.drawable.dislike);
                    }
                    try {
                        new rateWish().execute("");
                    } catch (Exception e) {
                        Toast.makeText(getActivity(), getString(R.string.NoInternetConnection), Toast.LENGTH_SHORT).show();
                    }

                }
            });

            wishViewHolder.shareImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent sendIntent = new Intent();
                    sendIntent.setAction(Intent.ACTION_SEND);
                    sendIntent.putExtra(Intent.EXTRA_TEXT, "Hey, check it!)) " + "wpw.tmweb.ru/" + wishes.get(i).wish_id);
                    sendIntent.setType("text/plain");
                    startActivity(sendIntent);
                }
            });
            wishViewHolder.commendImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    choise = wishes.get(i).wish_id;
                    String a = String.valueOf(getId);
                    SharedPreferences.Editor ed = sPref.edit();
                    ed.putString("nameAndSurname", getSurname + " " + getName);
                    ed.putString("wishText",wishes.get(i).wish);
                    ed.putString("choise", String.valueOf(choise));
                    ed.putString("user",a);
                    if (!getImage.equals("") && !getImage.equals(null)) {
                        ed.putString("userPage", getImage);
                    }
                    ed.apply();
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.replace(R.id.flContent, new CommentFragment(), "fragment_screen");
                    ft.addToBackStack(null);
                    ft.commit();
                }
            });

            wishViewHolder.wishImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (isImageFitToScreen) {
                        isImageFitToScreen = false;
                        wishViewHolder.wishImageView.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                        wishViewHolder.wishImageView.setAdjustViewBounds(true);
                    } else {
                        isImageFitToScreen = true;
                        wishViewHolder.wishImageView.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
                        wishViewHolder.wishImageView.setScaleType(ImageView.ScaleType.FIT_XY);
                    }
                }
            });

            wishViewHolder.reportImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getActivity(), ReportWishFragment.class);
                    intent.putExtra("wish_id", wishes.get(i).wish_id);
                    startActivity(intent);
                }
            });

        }

        @Override
        public int getItemCount() {
            return wishes.size();
        }

        @Override
        public void onAttachedToRecyclerView(RecyclerView recyclerView) {
            super.onAttachedToRecyclerView(recyclerView);
        }

        public class WishViewHolder extends RecyclerView.ViewHolder {

            CardView cv;
            TextView wishTextView;
            TextView countTextView;
            TextView commendCount;
            ImageView likeImageView;
            ImageView dislikeImageView;
            ImageView shareImageView;
            ImageView reportImageView;
            ImageView commendImageView;
            ImageView openOffer;
            ImageView wishImageView;

            WishViewHolder(View itemView) {
                super(itemView);
                cv = (CardView) itemView.findViewById(R.id.cv123);
                wishTextView = (TextView) itemView.findViewById(R.id.wishTextView);
                countTextView = (TextView) itemView.findViewById(R.id.countTextView);
                likeImageView = (ImageView) itemView.findViewById(R.id.likeImageView);
                dislikeImageView = (ImageView) itemView.findViewById(R.id.dislikeImageView);
                shareImageView = (ImageView) itemView.findViewById(R.id.shareNewImageView);
                reportImageView = (ImageView) itemView.findViewById(R.id.reportNewUserImageView);
                commendImageView = (ImageView) itemView.findViewById(R.id.commentNewUser);
                openOffer = (ImageView) itemView.findViewById(R.id.createOfferImageView);
                wishImageView = (ImageView) itemView.findViewById(R.id.newUserWishImage);
                commendCount = (TextView) itemView.findViewById(R.id.newUserPageCommentCount);
            }
        }
    }

    String getName, getSurname, getCity, getCountry, getCode, getImage, getFriend, getId;

    public void abc() throws JSONException {
        getCode = gettedInfo.getString("code");
        getId = gettedInfo.getString("id");
        getName = gettedInfo.getString("name");
        getSurname = gettedInfo.getString("surname");
        getCity = gettedInfo.getString("city");
        getCountry = gettedInfo.getString("country");
        getImage = gettedInfo.getString("image_path");
        getFriend = gettedInfo.getString("friend");
    }

    private class getUserInfo extends AsyncTask<String, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();

            multipartEntity.addPart("code", "getUserI");
            multipartEntity.addPart("user_id", sPref.getString("userId", ""));
            multipartEntity.addPart("friend_id", sPref.getString("choise",""));
            multipartEntity.addPart("lang", Locale.getDefault().getLanguage());

            httpPost.setEntity(multipartEntity);

            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                responseGettedInfo = EntityUtils.toString(entity);
                gettedInfo = new JSONObject(responseGettedInfo);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void o) {
            super.onPostExecute(o);
            Log.d("MYLOGS","gettedresponse: " + responseGettedInfo);
            try {
                abc();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            if (getCode.equals("1")){
                toolbar.setTitle(getName + " " + getSurname);
                cityandcountry.setText(getCity + ", " + getCountry);
                if (!getImage.equals("")){
                    Picasso.with(getActivity()).load(urlImage + getImage).into(backgroundImage);
                }
                if (getFriend.equals("1")){
                    addtofrind.setText(getString(R.string.DeleteFromFriend));
                }
            }
        }

    }

    private class usersWish extends AsyncTask<String, Void, Void>{

        @Override
        protected void onPreExecute() {
        }

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code","usersWishes");
            multipartEntity.addPart("user_id", sPref.getString("choise", ""));
            multipartEntity.addPart("lang", Locale.getDefault().getLanguage());

            httpPost.setEntity(multipartEntity);
            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                response = EntityUtils.toString(entity);

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        public void onPostExecute(Void o) {
            super.onPostExecute(o);
            Log.d("MYLOGS", response);
            if (response != null) {
                try {
                    wishObject = new JSONObject(response);
                    if (wishObject != null) {
                        wish = new ArrayList<String>();
                        num = new ArrayList<String>();
                        wish_image = new ArrayList<String>();
                        commendCount = new ArrayList<Integer>();
                        wish_id = new ArrayList<Integer>();
                        state = new ArrayList<Integer>();
                        apllied = new ArrayList<Integer>();
                        wishArray = wishObject.getJSONArray("usersWishes");
                        for (int i = 0; i < wishArray.length(); i++) {
                            JSONObject catObj = (JSONObject) wishArray.get(i);
                            num.add(catObj.getString("count_likes"));
                            wish_image.add(catObj.getString("wish_image_path"));
                            wish.add(catObj.getString("wish"));
                            wish_id.add(catObj.getInt("wish_id"));
                            state.add(catObj.getInt("state"));
                            apllied.add(catObj.getInt("wish_state"));
                            commendCount.add(catObj.getInt("count_comments"));
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            try {
                view.findViewById(R.id.loadingPanel1).setVisibility(View.GONE);
            } catch (Exception e) {

            }
            try {
                userswishes.setText("");
                initializeData();
                RVAdapter adapter = new RVAdapter(wishes);
                rv.setAdapter(adapter);
            }
            catch (Exception e){
                Toast.makeText(getActivity(),getString(R.string.NoInternetConnection),Toast.LENGTH_SHORT).show();
            }
        }

    }

    private class rateWish extends AsyncTask<String, Void, Void> {
        private rateWish() {

        }

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code","ratewish");
            multipartEntity.addPart("user_id", sPref.getString("userId", null));
            multipartEntity.addPart("wish_id", String.valueOf(choise));
            multipartEntity.addPart("state", String.valueOf(likeordislike));


            httpPost.setEntity(multipartEntity);
            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                response = EntityUtils.toString(entity);

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        public void onPostExecute(Void o){
            super.onPostExecute(o);
        }
    }

    private class addToFriend extends AsyncTask<String, Void, Void>{

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();

            multipartEntity.addPart("code", "addFriend");
            multipartEntity.addPart("user_id", sPref.getString("userId", ""));
            multipartEntity.addPart("friend_id", getId);

            httpPost.setEntity(multipartEntity);

            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                responseaddedtofriend = EntityUtils.toString(entity);

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}
