package com.example.koyash.whatpeoplewant;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.util.Locale;

public class ReportWishFragment extends Fragment implements View.OnClickListener{

    int wish_id,user_id;

    String response;

    final String url = "http://wpw.tmweb.ru/API.php";

    SharedPreferences sPref;

    Button reportbt;

    EditText reportText;

    String s;

    View view;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.activity_report_wish, container,
                false);

        sPref = getActivity().getSharedPreferences("APP", getContext().MODE_PRIVATE);

        if (sPref.getString("ch","") == "1"){
            wish_id = sPref.getInt("wish_id",0);
        }

        reportText = (EditText) view.findViewById(R.id.reportText);

        reportText.setOnClickListener(this);

        s = reportText.getText().toString();

        reportbt = (Button) view.findViewById(R.id.reportBt);

        reportbt.setOnClickListener(this);

        getActivity().setTitle(R.string.title_activity_write_report);

        return view;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                getActivity().onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onClick(View v) {
        try{
            switch (v.getId()){
                case R.id.reportBt:
                    s = reportText.getText().toString();
                    if (!s.equals(""))
                        new postReport().execute("");
                    else
                        Toast.makeText(getActivity(),getString(R.string.NullReport),Toast.LENGTH_SHORT).show();
                    break;
                default:
                    break;
            }
        }
        catch (Exception e){

        }
    }


    private class postReport extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();

            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code","report");
            multipartEntity.addPart("user_id", sPref.getString("userId", null));
            multipartEntity.addPart("wish_id", String.valueOf(wish_id));
            multipartEntity.addPart("report_text", s);
            multipartEntity.addPart("lang", Locale.getDefault().getLanguage());

            httpPost.setEntity(multipartEntity);

            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                response = EntityUtils.toString(entity);

            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }

        ProgressDialog dialog;

        @Override
        protected void onPreExecute(){
            super.onPreExecute();
            dialog = ProgressDialog.show(getActivity(),"",getString(R.string.Loading),true, true);
        }

        @Override
        protected void onPostExecute(Void o){
            super.onPostExecute(o);
            Log.d("MYLOGS", response);
            dialog.dismiss();
            if (response.equals("1"))
            {
                Toast.makeText(getActivity(),getString(R.string.Thanks),Toast.LENGTH_SHORT).show();
                getActivity().onBackPressed();
            }

        }
    }

}
