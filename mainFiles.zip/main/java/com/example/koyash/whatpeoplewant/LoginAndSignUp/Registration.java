package com.example.koyash.whatpeoplewant.LoginAndSignUp;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.koyash.whatpeoplewant.MultipartEntity;
import com.example.koyash.whatpeoplewant.R;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;


public class Registration extends AppCompatActivity {
    Button asd;
    TextView G1, G2, G3, G4, G5, G6, G7, G8;
    EditText name, surname, password, repassword, country, city, email;
    Spinner Country, City;
    String response, Semail, Spass, Sname, SSurname, Scountry, Scity, oldCountry;

    private static final String url = "http://wpw.tmweb.ru/API.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setContentView(R.layout.activity_registration);

        setTitle(getString(R.string.regist));

        asd = (Button) findViewById(R.id.REGIST);

        G1 = (TextView) findViewById(R.id.G1);
        G2 = (TextView) findViewById(R.id.G2);
        G3 = (TextView) findViewById(R.id.G3);
        G4 = (TextView) findViewById(R.id.G4);
        G5 = (TextView) findViewById(R.id.G5);
        G6 = (TextView) findViewById(R.id.G6);
        G7 = (TextView) findViewById(R.id.G7);
        G8 = (TextView) findViewById(R.id.G8);

        Country = (Spinner) findViewById(R.id.spinner);
        City = (Spinner) findViewById(R.id.spinner2);

        name = (EditText) findViewById(R.id.NAME);
        surname = (EditText) findViewById(R.id.SURNAME);
        password = (EditText) findViewById(R.id.PASSWORD);
        repassword = (EditText) findViewById(R.id.PASSWORD1);
        country = (EditText) findViewById(R.id.COUNTRY);
        city = (EditText) findViewById(R.id.CITY);
        email = (EditText) findViewById(R.id.EMAIL);

        asd.setOnClickListener(onClickListener);

        try {
            new uploadCountry().execute("");
        } catch (Exception e) {
            Toast.makeText(Registration.this, "NO Internet Connection", Toast.LENGTH_SHORT).show();
        }
        Country.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                new uploadCity().execute("");

            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void proverka() {
        Toast.makeText(this, getString(R.string.OneField), Toast.LENGTH_SHORT).show();
    }

    public void wrpass() {
        Toast.makeText(this, getString(R.string.Passwords), Toast.LENGTH_SHORT).show();
    }

    ArrayAdapter<String> adapter;

    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            try {
                switch (v.getId()) {
                    case R.id.REGIST:

                        G1.setVisibility(View.INVISIBLE);
                        G2.setVisibility(View.INVISIBLE);
                        G3.setVisibility(View.INVISIBLE);
                        G4.setVisibility(View.INVISIBLE);
                        G5.setVisibility(View.INVISIBLE);
                        G6.setVisibility(View.INVISIBLE);
                        G7.setVisibility(View.INVISIBLE);
                        G8.setVisibility(View.INVISIBLE);

                        int k = 0;

                        if (name.getText().toString().equals("")) {
                            k++;
                            G1.setVisibility(View.VISIBLE);
                            proverka();
                        } else {
                            Sname = name.getText().toString();
                        }
                        if (surname.getText().toString().equals("")) {
                            if (k == 0)
                                proverka();
                            k++;
                            G2.setVisibility(View.VISIBLE);
                        } else {
                            SSurname = surname.getText().toString();
                        }
                        if (password.getText().toString().equals("")) {
                            if (k == 0)
                                proverka();
                            k++;
                            G4.setVisibility(View.VISIBLE);
                        }
                        if (repassword.getText().toString().equals("")) {
                            if (k == 0)
                                proverka();
                            k++;
                            G5.setVisibility(View.VISIBLE);

                        }
                        if (!password.getText().toString().equals(repassword.getText().toString())) {
                            k++;
                            G5.setVisibility(View.VISIBLE);
                            wrpass();
                        } else {
                            Spass = password.getText().toString();
                        }
                        if (Country.getSelectedItem().toString().equals("")) {
                            if (k == 0) {
                                proverka();
                            }
                            k++;
                            G6.setVisibility(View.VISIBLE);
                        } else {
                            Scountry = Country.getSelectedItem().toString();
                            oldCountry = Country.getSelectedItem().toString();
                        }
                        if (!Country.toString().equals("")) {

                        }
                        if (City.getSelectedItem().toString().equals(null)) {
                            k++;
                            G7.setVisibility(View.VISIBLE);
                            if (k == 0)
                                proverka();
                        } else {
                            Scity = City.getSelectedItem().toString();
                        }
                        if (email.getText().toString().equals("")) {
                            if (k == 0)
                                proverka();
                            k++;
                            G8.setVisibility(View.VISIBLE);
                        } else {
                            Semail = email.getText().toString();
                        }
                        if (k == 0) {
                            new uploadTask().execute("");
                        }
                        break;
                    default:
                        break;
                }
            } catch (Exception e) {
                Toast.makeText(Registration.this, getString(R.string.NoInternetConnection), Toast.LENGTH_LONG).show();
            }
        }
    };


    JSONObject countrys;
    JSONArray countrys1;
    List<String> allcountrys = new ArrayList<String>();

    public class uploadCountry extends AsyncTask<String, Void, Void> {
        private uploadCountry() {

        }

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code", "getCountry");
            multipartEntity.addPart("lang", Locale.getDefault().getLanguage());

            httpPost.setEntity(multipartEntity);

            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                response = EntityUtils.toString(entity);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        private Dialog dialog;

        @Override
        protected void onPreExecute() {
            dialog = ProgressDialog.show(Registration.this, getString(R.string.Loading), getString(R.string.Country), true, false);
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Void o) {
            super.onPostExecute(o);

            dialog.dismiss();

            if (response != null) {
                try {
                    countrys = new JSONObject(response);
                    {
                        if (countrys != null) {
                            countrys1 = countrys.getJSONArray("countries");

                            for (int i = 0; i < countrys1.length(); i++) {
                                JSONObject catObj = (JSONObject) countrys1.get(i);
                                allcountrys.add(catObj.getString("co" +
                                        "ntry"));
                            }
                        }
                    }
                } catch (Exception e) {

                }
            }
            else{
                Toast.makeText(Registration.this,getString(R.string.NoInternetConnection),Toast.LENGTH_SHORT).show();
            }
            try {
                adapter = new ArrayAdapter<String>(Registration.this, android.R.layout.simple_spinner_dropdown_item, allcountrys);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                Country.setAdapter(adapter);
            } catch (Exception e) {
                Toast.makeText(Registration.this, "No Internet connection or problems in server", Toast.LENGTH_SHORT).show();
            }

        }

    }

    JSONObject citys;
    JSONArray citys1;
    List<String> allcitys = new ArrayList<String>();
    String s;

    private class uploadCity extends AsyncTask<String, Void, Void> {


        ProgressDialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            s = Country.getSelectedItem().toString();
            dialog = ProgressDialog.show(Registration.this, getString(R.string.Loading), getString(R.string.City), true, true);
        }

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code", "getCity");
            multipartEntity.addPart("country", s);
            multipartEntity.addPart("lang", Locale.getDefault().getLanguage());

            httpPost.setEntity(multipartEntity);

            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                response = EntityUtils.toString(entity);
            } catch (IOException e) {
                Toast.makeText(Registration.this, "Sorry problems", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
            return null;
        }


        @Override
        protected void onPostExecute(Void o) {
            super.onPostExecute(o);
            dialog.dismiss();
            if (response != null) {
                try {
                    citys = new JSONObject(response);
                    if (citys != null) {
                        citys1 = citys.getJSONArray("cities");
                        allcitys.clear();
                        for (int i = 0; i < citys1.length(); i++) {
                            JSONObject catObj = (JSONObject) citys1.get(i);
                            allcitys.add(catObj.getString("city"));
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            else{
                Toast.makeText(Registration.this,getString(R.string.NoInternetConnection),Toast.LENGTH_SHORT).show();
            }
            try {
                City.setAdapter(null);
                adapter = new ArrayAdapter<String>(Registration.this, android.R.layout.simple_spinner_dropdown_item, allcitys);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                City.setAdapter(adapter);
            } catch (Exception e) {
                Toast.makeText(Registration.this, getString(R.string.NoInternetConnection), Toast.LENGTH_SHORT).show();
            }
        }
    }

    private class uploadTask extends AsyncTask<String, Void, Void> {
        private uploadTask() {

        }

        private ProgressDialog dialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = ProgressDialog.show(Registration.this, "", getString(R.string.Loading),true,true);
        }

        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code", "newUser");
            multipartEntity.addPart("email", Semail);
            multipartEntity.addPart("password", Spass);
            multipartEntity.addPart("name", Sname);
            multipartEntity.addPart("surname", SSurname);
            multipartEntity.addPart("country", Scountry);
            multipartEntity.addPart("city", Scity);

            httpPost.setEntity(multipartEntity);

            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                response = EntityUtils.toString(entity);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }


        @Override
        protected void onPostExecute(Void o) {
            super.onPostExecute(o);
            dialog.dismiss();
            if (response.equals("1")) {
                Toast.makeText(Registration.this, getString(R.string.succesRegist), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Registration.this, LoginActivity.class);
                intent.putExtra("ch", 1);
                intent.putExtra("login", email.getText().toString());
                intent.putExtra("pass", password.getText().toString());
                startActivity(intent);
                finish();

            }
            if (response.equals("2")) {
                Toast.makeText(Registration.this, getString(R.string.somethingWrong), Toast.LENGTH_SHORT).show();
            }
            if (response.equals("3")){
                Toast.makeText(Registration.this, getString(R.string.emailWrong), Toast.LENGTH_SHORT).show();
            }
        }
    }
}

