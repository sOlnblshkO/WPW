package com.example.koyash.whatpeoplewant.LoginAndSignUp;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.koyash.whatpeoplewant.MultipartEntity;
import com.example.koyash.whatpeoplewant.R;
import com.google.android.gms.common.api.GoogleApiClient;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

import java.io.IOException;

public class DontRemember extends AppCompatActivity {
    Button Send, Back;
    EditText text1email;

    String url = "http://wpw.tmweb.ru/API.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dont_remember);

        Send = (Button) findViewById(R.id.send);
        Back = (Button) findViewById(R.id.back);

        Send.setOnClickListener(onClickListener);
        Back.setOnClickListener(onClickListener);

        text1email=(EditText)findViewById(R.id.editText3);
    }
    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.send:
                    if (text1email.getText().toString().equals("")) {
                        Toast.makeText(DontRemember.this, getString(R.string.error_field_required), Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(DontRemember.this, getString(R.string.sentPass), Toast.LENGTH_LONG).show();
                        new sendEmail().execute("");
                        onBackPressed();
                        break;
                    }
                case R.id.back:
                {
                    onBackPressed();
                    break;
                }
                default:
                    break;
            }
        }
    };

    String response;

    private class sendEmail extends AsyncTask<String, Void, Void>{

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();

            multipartEntity.addPart("code","restorePass");
            multipartEntity.addPart("email",text1email.getText().toString());

            httpPost.setEntity(multipartEntity);

            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                response = EntityUtils.toString(entity);

            } catch (IOException e) {

            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            Log.d("MYLOGS", response);
        }
    }

}
