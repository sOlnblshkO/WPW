package com.example.koyash.whatpeoplewant.LoginAndSignUp;


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;

import com.example.koyash.whatpeoplewant.LoginAndSignUp.CustomDialogExit;
import com.example.koyash.whatpeoplewant.MenuFragments.AboutFragment;
import com.example.koyash.whatpeoplewant.MenuFragments.EditUsersInfoFragment;
import com.example.koyash.whatpeoplewant.MenuFragments.MyFriendFragment;
import com.example.koyash.whatpeoplewant.MenuFragments.NewsFragment;
import com.example.koyash.whatpeoplewant.MenuFragments.StatisticFragment;
import com.example.koyash.whatpeoplewant.MenuFragments.UserPageFragment;
import com.example.koyash.whatpeoplewant.R;


public class Menu extends AppCompatActivity {

    private DrawerLayout mDrawer;
    NavigationView nvDrawer;
    Toolbar toolbar;
    ActionBarDrawerToggle drawerToggle;

    Fragment fragment = null;
    Class fragmentClass = UserPageFragment.class;
    FragmentManager fragmentManager;

    SharedPreferences sPref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        sPref = this.getSharedPreferences("APP",MODE_PRIVATE);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mDrawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        nvDrawer = (NavigationView) findViewById(R.id.nvView);

        mDrawer.addDrawerListener(drawerToggle);

        setupDrawerContent(nvDrawer);

        try {
            fragment = (Fragment) fragmentClass.newInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }

        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.flContent, fragment).commit();

        mDrawer.closeDrawers();

        setupDrawer();

        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private ActionBarDrawerToggle setupDrawerToggle() {
        return new ActionBarDrawerToggle(this, mDrawer, toolbar, R.string.drawer_open,  R.string.drawer_close);
    }

    private void setupDrawer() {
        drawerToggle = new ActionBarDrawerToggle(Menu.this, mDrawer,
                R.string.drawer_open, R.string.drawer_close) {

            /** Called when a drawer has settled in a completely open state. */
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                invalidateOptionsMenu();
            }

            /** Called when a drawer has settled in a completely closed state. */
            public void onDrawerClosed(View view) {
                super.onDrawerClosed(view);
                invalidateOptionsMenu();
            }
        };
        drawerToggle.setDrawerIndicatorEnabled(true);
        mDrawer.setDrawerListener(drawerToggle);
    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // The action bar home/up action should open or close the drawer.
        switch (item.getItemId()) {
            case android.R.id.home:
                mDrawer.openDrawer(GravityCompat.START);
                return true;
        }

        if (drawerToggle.onOptionsItemSelected(item)) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        drawerToggle.syncState();

    }

    private void setupDrawerContent(NavigationView navigationView) {
        navigationView.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(MenuItem menuItem) {
                        selectDrawerItem(menuItem);
                        return true;
                    }
                });
    }

    public void selectDrawerItem(MenuItem menuItem) {
        // Create a new fragment and specify the fragment to show based on nav item clicked
        fragment = null;
        switch (menuItem.getItemId()) {
            case R.id.nav_friend:
                getSupportActionBar().setTitle(getString(R.string.title_activity_friends));
                fragmentClass = MyFriendFragment.class;
                break;
            case R.id.nav_news:
                getSupportActionBar().setTitle(getString(R.string.title_activity_news));
                fragmentClass = NewsFragment.class;
                break;
            case R.id.nav_info:
                getSupportActionBar().setTitle(getString(R.string.app_name));
                fragmentClass = AboutFragment.class;
                break;
            case R.id.nav_user:
                getSupportActionBar().setTitle(getString(R.string.title_activity_new_user_page));
                fragmentClass = UserPageFragment.class;
                break;
            case R.id.nav_statistic:
                getSupportActionBar().setTitle(getString(R.string.title_activity_statistic));
                fragmentClass = StatisticFragment.class;
                break;
            case R.id.nav_settings:
                getSupportActionBar().setTitle(getString(R.string.Edit));
                fragmentClass = EditUsersInfoFragment.class;
                break;
            case R.id.nav_exit:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage("Are you sure you want to exit?")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                SharedPreferences.Editor ed = sPref.edit().clear();
                                ed.apply();
                                Intent intent = new Intent(Menu.this, LoginActivity.class);
                                startActivity(intent);
                                finish();
                                Menu.this.finish();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                AlertDialog alert = builder.create();
                alert.show();
                break;
            default:
                fragmentClass = UserPageFragment.class;
        }

        try {
            fragment = (Fragment) fragmentClass.newInstance();
        } catch (Exception e) {

        }

        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.flContent, fragment).addToBackStack(null).commit();

        menuItem.setChecked(true);

        mDrawer.closeDrawers();
    }


}
