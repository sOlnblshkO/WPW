package com.example.koyash.whatpeoplewant.tabs;

import android.app.Activity;
import android.os.Bundle;

import com.example.koyash.whatpeoplewant.R;

/**
 * Created by Koyawkay on 18.06.2016.
 */
public class users_wishes extends Activity {
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.users_wishes);

    }
}
