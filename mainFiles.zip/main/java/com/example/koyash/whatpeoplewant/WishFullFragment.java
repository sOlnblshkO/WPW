package com.example.koyash.whatpeoplewant;

import android.content.SharedPreferences;
import android.media.Image;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Created by koyash on 04.05.16.
 */
public class WishFullFragment extends Fragment implements View.OnClickListener {

    String wishId;

    final String url = "http://wpw.tmweb.ru/API.php";
    final String urlImage = "http://wpw.tmweb.ru/";

    String responseCommends,text, userId, response, responseName;

    JSONObject commendObject;
    JSONArray commendArray;

    List<String> ownerId = new ArrayList<String>();
    List<String> ownerPhoto = new ArrayList<String>();
    List<String> ownerName = new ArrayList<String>();
    List<String> ownerSurname = new ArrayList<String>();
    List<String> commend = new ArrayList<String>();
    List<String> date = new ArrayList<String>();
    RecyclerView rv;

    ImageView sendCommend;

    SharedPreferences sPref;

    EditText commendText;

    TextView wishText, nameAndSurname, textView;

    View view;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {


        wishId = getActivity().getIntent().getData().getPathSegments().get(0);
        view = inflater.inflate(R.layout.activity_commend_fragment, container,
                false);

        sPref = getActivity().getSharedPreferences("APP", getActivity().MODE_PRIVATE);

        commendText = (EditText) view.findViewById(R.id.commendText);
        textView = (TextView) view.findViewById(R.id.textView123);
        sendCommend = (ImageView) view.findViewById(R.id.sendCommendImageView);

        rv = (RecyclerView) view.findViewById(R.id.rvCommend);
        LinearLayoutManager llm = new LinearLayoutManager(getContext());
        rv.setLayoutManager(llm);

        wishText = (TextView) view.findViewById(R.id.wishText);
        nameAndSurname = (TextView) view.findViewById(R.id.nameAndSurname);

        new getWish().execute("");

        if (sPref.getString("userId", "").equals("")) {
            commendText.setVisibility(View.INVISIBLE);
            sendCommend.setVisibility(View.INVISIBLE);
            textView.setVisibility(View.INVISIBLE);
            userId = sPref.getString("userId","");
            new getCommends().execute("");
            Toast.makeText(getActivity(), getString(R.string.CheckLoggined), Toast.LENGTH_LONG).show();
        } else {
            userId = sPref.getString("userId","");
            new getCommends().execute("");
            sendCommend.setOnClickListener(this);
        }

        return view;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                getActivity().onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.sendCommendImageView:
                if (commendText.length() != 0) {
                    text = commendText.getText().toString();
                    commendText.setText("");
                    new sendCommends().execute("");
                }
                else{
                    Toast.makeText(getContext(),getString(R.string.WriteMore),Toast.LENGTH_SHORT).show();
                }
                break;
            default:
                break;
        }
    }

    class commendsConteiner {

        String id;
        String photo;
        String name;
        String surname;
        String date;
        String commend;

        commendsConteiner(String id, String photo, String name, String surname, String date, String commend) {
            this.id = id;
            this.photo = photo;
            this.name = name;
            this.surname = surname;
            this.date = date;
            this.commend = commend;
        }

    }

    private List<commendsConteiner> commends;

    private void initializeData() {
        commends = new ArrayList<>();
        rv.setAdapter(null);
        if (ownerName.size() > 0) {
            for (int i = 0; i < ownerName.size(); i++)
                commends.add(new commendsConteiner(ownerId.get(i), ownerPhoto.get(i), ownerName.get(i), ownerSurname.get(i), commend.get(i), date.get(i)));
        }

    }

    public class RVAdapter extends RecyclerView.Adapter<RVAdapter.WishViewHolder> {

        List<commendsConteiner> commends;
        public RVAdapter(List<commendsConteiner> commends) {
            this.commends = commends;
        }

        @Override
        public WishViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.commends_adapter, viewGroup, false);
            WishViewHolder wishViewHolder = new WishViewHolder(v);
            return wishViewHolder;
        }

        @Override
        public void onBindViewHolder(final WishViewHolder commendViewHolder, final int i) {
            commendViewHolder.nameTextView.setText(commends.get(i).name + " " + commends.get(i).surname);
            commendViewHolder.dateTextView.setText(commends.get(i).commend);
            commendViewHolder.commendTextView.setText(commends.get(i).date);
            if (commends.get(i).photo.equals("")){
                commendViewHolder.ownerPhoto.setImageResource(R.drawable.user);
            }
            else
                Picasso.with(getActivity()).load(urlImage + commends.get(i).photo).into(commendViewHolder.ownerPhoto);
        }

        @Override
        public int getItemCount() {
            return commends.size();
        }

        @Override
        public void onAttachedToRecyclerView(RecyclerView recyclerView) {
            super.onAttachedToRecyclerView(recyclerView);
        }

        public class WishViewHolder extends RecyclerView.ViewHolder {

            CardView cv;
            TextView nameTextView;
            TextView dateTextView;
            TextView commendTextView;
            ImageView ownerPhoto;

            WishViewHolder(View itemView) {
                super(itemView);
                cv = (CardView)itemView.findViewById(R.id.cvCommend);
                nameTextView = (TextView)itemView.findViewById(R.id.ownerCommendTextView);
                dateTextView = (TextView)itemView.findViewById(R.id.dateCommend);
                commendTextView = (TextView)itemView.findViewById(R.id.commendTextView);
                ownerPhoto = (ImageView)itemView.findViewById(R.id.commentOwnerIamge);
            }
        }

    }

    private class getNameSurname extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code","getName");
            multipartEntity.addPart("wish_id", wishId);
            multipartEntity.addPart("lang", Locale.getDefault().getLanguage());

            httpPost.setEntity(multipartEntity);

            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                responseName = EntityUtils.toString(entity);
            }
            catch (Exception e) {

            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            JSONObject json = null;
            try {
                json = new JSONObject(responseName);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            try {
                Log.d("MYLOGS","1");
                nameAndSurname.setText(json.getString("name") + "\n" + json.getString("surname"));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }



    private class getWish extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code","getWishFull");
            multipartEntity.addPart("wish_id",wishId);

            httpPost.setEntity(multipartEntity);

            HttpResponse httpResponse = null;
            try{
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity =httpResponse.getEntity();
                response = EntityUtils.toString(entity);
            }
            catch (Exception e){

            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            Log.d("MYLOGS", response);
            try {
                JSONObject json = new JSONObject(response);
                wishText.setText(json.getString("wish_text"));
                new getNameSurname().execute("");
            } catch (Exception e) {
                Toast.makeText(getActivity(), "No Internet Connection", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private class getCommends extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code","getComments");
            multipartEntity.addPart("user_id", userId);
            multipartEntity.addPart("wish_id", wishId);

            httpPost.setEntity(multipartEntity);

            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                responseCommends = EntityUtils.toString(entity);

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void o){
            super.onPostExecute(o);
            Log.d("MYLOGS",responseCommends);
            try{
                commendObject = new JSONObject(responseCommends);
                commendArray = commendObject.getJSONArray("comments");
                ownerPhoto = new ArrayList<String>();
                ownerId = new ArrayList<String>();
                ownerName = new ArrayList<String>();
                ownerSurname = new ArrayList<String>();
                commend = new ArrayList<String>();
                date = new ArrayList<String>();
                for (int i=0; i < commendArray.length(); i++){
                    JSONObject catObj = (JSONObject) commendArray.get(i);
                    ownerName.add(catObj.getString("name"));
                    ownerSurname.add(catObj.getString("surname"));
                    commend.add(catObj.getString("comment_text"));
                    date.add(catObj.getString("time"));
                    ownerId.add(catObj.getString("user_id"));
                    ownerPhoto.add(catObj.getString(""));
                }
            }
            catch (JSONException e){

            }

            view.findViewById(R.id.loadingPanelCommend).setVisibility(View.GONE);
            initializeData();
            RVAdapter adapter = new RVAdapter(commends);
            rv.setAdapter(null);
            rv.setAdapter(adapter);

        }
    }

    private class sendCommends extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code","addComment");
            multipartEntity.addPart("user_id", userId);
            multipartEntity.addPart("wish_id", wishId);
            multipartEntity.addPart("comment_text", text);

            httpPost.setEntity(multipartEntity);

            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                responseCommends = EntityUtils.toString(entity);

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void o){
            super.onPostExecute(o);
            new getCommends().execute("");
        }
    }
}
