package com.example.koyash.whatpeoplewant;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;

public class CommentFragment extends Fragment implements View.OnClickListener {

    final String url = "http://wpw.tmweb.ru/API.php";
    final String urlImage = "http://wpw.tmweb.ru/";
    String responseCommends,text, responseInfo;

    JSONObject commendObject;
    JSONArray commendArray;

    List<String> ownerId = new ArrayList<String>();
    List<String> ownerPhoto = new ArrayList<String>();
    List<String> ownerName = new ArrayList<String>();
    List<String> ownerSurname = new ArrayList<String>();
    List<String> commend = new ArrayList<String>();
    List<String> date = new ArrayList<String>();
    RecyclerView rv;

    ImageView sendCommend;

    CircleImageView usersWishesCommentPage;

    SharedPreferences sPref;

    EditText commendText;

    TextView wishText, nameAndSurname;

    View view;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.activity_commend_fragment, container,
                false);

        sPref = getActivity().getSharedPreferences("APP",getActivity().MODE_PRIVATE);

        usersWishesCommentPage = (CircleImageView) view.findViewById(R.id.usersWishesCommentPage);

        commendText = (EditText) view.findViewById(R.id.commendText);

        sendCommend = (ImageView) view.findViewById(R.id.sendCommendImageView);

        rv = (RecyclerView) view.findViewById(R.id.rvCommend);
        LinearLayoutManager llm = new LinearLayoutManager(getContext());
        rv.setLayoutManager(llm);

        wishText = (TextView) view.findViewById(R.id.wishText);
        nameAndSurname = (TextView) view.findViewById(R.id.nameAndSurname);

        wishText.setText(sPref.getString("wishText", ""));

        new getCommends().execute("");

        new getUserInfo().execute("");

        nameAndSurname.setOnClickListener(this);
        usersWishesCommentPage.setOnClickListener(this);
        sendCommend.setOnClickListener(this);


        try {

        }
        catch (Exception e){

        }

        getActivity().setTitle(getString(R.string.Comments));

        return view;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                getActivity().onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.nameAndSurname:
                if (!sPref.getString("user", "").equals(sPref.getString("userId",""))) {
                    SharedPreferences.Editor ed = sPref.edit();
                    ed.putString("choise", sPref.getString("user",  ""));
                    ed.apply();
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.replace(R.id.flContent, new NewUserPageFragment(), "fragment_screen");
                    ft.addToBackStack(null);
                    ft.commit();
                }
                else{
                    Toast.makeText(getActivity(),getString(R.string.ThisIsYou),Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.usersWishesCommentPage:
                if (!sPref.getString("user", "")
                        .equals(sPref.getString("userId",""))) {
                    SharedPreferences.Editor ed = sPref.edit();
                    ed.putString("choise", sPref.getString("user",  ""));
                    ed.apply();
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.replace(R.id.flContent, new NewUserPageFragment(), "fragment_screen");
                    ft.addToBackStack(null);
                    ft.commit();
                }
                else{
                    Toast.makeText(getActivity(),getString(R.string.ThisIsYou),Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.sendCommendImageView:
                if (commendText.length() != 0) {
                    text = commendText.getText().toString();
                    commendText.setText("");
                    new sendCommends().execute("");
                }
                else{
                    Toast.makeText(getContext(),getString(R.string.WriteCommentss),Toast.LENGTH_SHORT).show();
                }
                break;
            default:
                break;
        }
    }

    class commendsConteiner {

        String id;
        String name;
        String surname;
        String date;
        String commend;
        String ownerPhoto;

        commendsConteiner(String id, String name, String surname, String date, String commend, String ownerPhoto) {
            this.id = id;
            this.name = name;
            this.surname = surname;
            this.date = date;
            this.commend = commend;
            this.ownerPhoto = ownerPhoto;
        }

    }

    private List<commendsConteiner> commends;

    private void initializeData() {
        commends = new ArrayList<>();
        rv.setAdapter(null);
        if (ownerName.size() > 0) {
            for (int i = 0; i < ownerName.size(); i++)
                commends.add(new commendsConteiner(ownerId.get(i), ownerName.get(i), ownerSurname.get(i), commend.get(i), date.get(i), ownerPhoto.get(i)));
        }

    }

    public class RVAdapter extends RecyclerView.Adapter<RVAdapter.WishViewHolder> {

        List<commendsConteiner> commends;
        public RVAdapter(List<commendsConteiner> commends) {
            this.commends = commends;
        }

        @Override
        public WishViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.commends_adapter, viewGroup, false);
            WishViewHolder wishViewHolder = new WishViewHolder(v);
            return wishViewHolder;
        }

        @Override
        public void onBindViewHolder(final WishViewHolder commendViewHolder, final int i) {
            commendViewHolder.nameTextView.setText(commends.get(i).name + " " + commends.get(i).surname);
            commendViewHolder.dateTextView.setText(commends.get(i).commend);
            commendViewHolder.commendTextView.setText(commends.get(i).date);

            if (commends.get(i).ownerPhoto.equals("") || commends.get(i).ownerPhoto.equals(null)){
                commendViewHolder.ownerPhoto.setImageResource(R.drawable.user);
            }
            else{
                Picasso.with(getActivity())
                        .load(urlImage + commends.get(i).ownerPhoto)
                        .into(commendViewHolder.ownerPhoto);
            }

            commendViewHolder.nameTextView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (!sPref.getString("userId","").equals(commends.get(i).id)) {
                        SharedPreferences.Editor ed = sPref.edit();
                        ed.putString("choise", commends.get(i).id);
                        ed.putString("friend","1");
                        ed.apply();
                        FragmentManager fm = getFragmentManager();
                        FragmentTransaction ft = fm.beginTransaction();
                        ft.replace(R.id.flContent, new NewUserPageFragment(), "fragment_screen");
                        ft.addToBackStack(null);
                        ft.commit();
                    }
                    else{
                        Toast.makeText(getActivity(),getString(R.string.ThisIsYou), Toast.LENGTH_SHORT).show();
                    }
                }
            });
            commendViewHolder.ownerPhoto.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!sPref.getString("userId","").equals(commends.get(i).id)) {
                        SharedPreferences.Editor ed = sPref.edit();
                        ed.putString("choise", commends.get(i).id);
                        ed.putString("friend","1");
                        ed.apply();
                        FragmentManager fm = getFragmentManager();
                        FragmentTransaction ft = fm.beginTransaction();
                        ft.replace(R.id.flContent, new NewUserPageFragment(), "fragment_screen");
                        ft.addToBackStack(null);
                        ft.commit();
                    }
                    else{
                        Toast.makeText(getActivity(),getString(R.string.ThisIsYou), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        @Override
        public int getItemCount() {
            return commends.size();
        }

        @Override
        public void onAttachedToRecyclerView(RecyclerView recyclerView) {
            super.onAttachedToRecyclerView(recyclerView);
        }

        public class WishViewHolder extends RecyclerView.ViewHolder {

            CardView cv;
            TextView nameTextView;
            TextView dateTextView;
            TextView commendTextView;
            CircleImageView ownerPhoto;

            WishViewHolder(View itemView) {
                super(itemView);
                cv = (CardView)itemView.findViewById(R.id.cvCommend);
                nameTextView = (TextView)itemView.findViewById(R.id.ownerCommendTextView);
                dateTextView = (TextView)itemView.findViewById(R.id.dateCommend);
                commendTextView = (TextView)itemView.findViewById(R.id.commendTextView);
                ownerPhoto = (CircleImageView) itemView.findViewById(R.id.commentOwnerIamge);
            }
        }

    }

    private class getUserInfo extends AsyncTask<String, Void, Void>{

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code", "getUserInfo");
            multipartEntity.addPart("user_id", sPref.getString("user", ""));
            multipartEntity.addPart("wish_id", sPref.getString("choise",""));

            httpPost.setEntity(multipartEntity);

            HttpResponse httpResponse = null;
            try{
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                responseInfo = EntityUtils.toString(entity);
            }  catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            Log.d("MYLOGS", responseInfo);
            try {
                JSONObject userinfo = new JSONObject(responseInfo);
                nameAndSurname.setText(userinfo.getString("name") + " " + userinfo.getString("surname"));
                if (!userinfo.getString("image_path").equals("") && !userinfo.getString("image_path").equals(null)) {
                    Picasso.with(getContext()).load(urlImage + userinfo.getString("image_path")).into(usersWishesCommentPage);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class getCommends extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code","getComments");
            multipartEntity.addPart("user_id", sPref.getString("user", ""));
            multipartEntity.addPart("wish_id", sPref.getString("choise", ""));

            httpPost.setEntity(multipartEntity);

            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                responseCommends = EntityUtils.toString(entity);

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void o){
            super.onPostExecute(o);
            Log.d("MYLOGS",responseCommends);
            try{
                commendObject = new JSONObject(responseCommends);
                commendArray = commendObject.getJSONArray("comments");
                ownerId = new ArrayList<String>();
                ownerPhoto = new ArrayList<String>();
                ownerName = new ArrayList<String>();
                ownerSurname = new ArrayList<String>();
                commend = new ArrayList<String>();
                date = new ArrayList<String>();
                for (int i=0;i<commendArray.length();i++){
                    JSONObject catObj = (JSONObject) commendArray.get(i);
                    ownerId.add(catObj.getString("user_id"));
                    ownerPhoto.add(catObj.getString("owner_photo"));
                    ownerName.add(catObj.getString("name"));
                    ownerSurname.add(catObj.getString("surname"));
                    commend.add(catObj.getString("comment_text"));
                    date.add(catObj.getString("time"));
                }
            }
            catch (JSONException e){

            }

            view.findViewById(R.id.loadingPanelCommend).setVisibility(View.GONE);
            initializeData();
            RVAdapter adapter = new RVAdapter(commends);
            rv.setAdapter(null);
            rv.setAdapter(adapter);

        }
    }

    private class sendCommends extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code","addComment");
            multipartEntity.addPart("user_id", sPref.getString("userId", null));
            multipartEntity.addPart("wish_id", sPref.getString("choise",""));
            multipartEntity.addPart("comment_text", text);
            multipartEntity.addPart("lang", Locale.getDefault().getLanguage());

            httpPost.setEntity(multipartEntity);

            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                responseCommends = EntityUtils.toString(entity);

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void o){
            super.onPostExecute(o);
            new getCommends().execute("");
        }
    }

}
