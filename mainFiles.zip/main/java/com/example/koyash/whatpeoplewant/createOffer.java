package com.example.koyash.whatpeoplewant;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import java.io.IOException;

public class createOffer extends AppCompatActivity implements View.OnClickListener {

    EditText projectName, projectDescription;

    TextView p1,p2;

    Button create;

    final String url = "http://cg42326.tmweb.ru/API.php";

    String SprojectName, SprojectDescription, response;

    SharedPreferences sPref;

    String wish_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setContentView(R.layout.activity_create_offer);

        if (getIntent().getStringExtra("ch").equals("1")){
            wish_id = getIntent().getStringExtra("wish_id");
        }

        projectName = (EditText) findViewById(R.id.editNameProject);
        projectDescription = (EditText) findViewById(R.id.descriptionOfProject);

        create = (Button) findViewById(R.id.newProjectBt);

        create.setOnClickListener(this);

        p1 = (TextView) findViewById(R.id.textIncorrectOffer1);
        p2 = (TextView) findViewById(R.id.textIncorrectOffer2);
        p1.setVisibility(View.INVISIBLE);
        p2.setVisibility(View.INVISIBLE);

        sPref = createOffer.this.getSharedPreferences("APP", createOffer.this.MODE_PRIVATE);

        AlertDialog ad = new AlertDialog.Builder(this)
                .create();
        ad.setCancelable(true);
        ad.setMessage(getString(R.string.FullfilDesire));
        ad.setButton(getString(R.string.Ok), new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        ad.show();

        setTitle(R.string.CreateOffer);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.newProjectBt:
                SprojectName = projectName.getText().toString();
                SprojectDescription = projectDescription.getText().toString();
                if (SprojectName.length() < 3 || SprojectDescription.length() < 10){
                    Toast.makeText(createOffer.this,getString(R.string.MoreProject),Toast.LENGTH_SHORT).show();
                    if (SprojectName.length() < 3)
                        p1.setVisibility(View.VISIBLE);
                    else
                        p1.setVisibility(View.INVISIBLE);
                    if (SprojectDescription.length() < 10)
                        p2.setVisibility(View.VISIBLE);
                    else
                        p2.setVisibility(View.INVISIBLE);
                }
                else{
                    new sendProject().execute("");
                }
                break;
            default:
                break;
        }
    }

    private class sendProject extends AsyncTask<String, Void, Void>
    {


        @Override
        protected Void doInBackground(String... params) {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code", "addOffer");
            multipartEntity.addPart("offer_name",SprojectName);
            multipartEntity.addPart("offer_text",SprojectDescription);
            multipartEntity.addPart("user_id",sPref.getString("userId", null));
            multipartEntity.addPart("wish_id",wish_id);

            httpPost.setEntity(multipartEntity);

            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                response = EntityUtils.toString(entity);

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void o){
            super.onPostExecute(o);
            Toast.makeText(createOffer.this, getString(R.string.ProjectAdded), Toast.LENGTH_SHORT).show();
            onBackPressed();
            finish();
        }
    }
}
