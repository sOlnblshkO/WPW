package com.example.koyash.whatpeoplewant;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

public class createNewWish extends AppCompatActivity implements View.OnClickListener {

    Button creatNewWish;

    EditText descript;

    int uploaded = 0;

    String s,email,response;
    final String url = "http://wpw.tmweb.ru/API.php";

    SharedPreferences sPref;

    ImageView uploadWishPhoto;

    Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setContentView(R.layout.activity_create_new_wish);

        sPref = getSharedPreferences("APP", this.MODE_PRIVATE);

        creatNewWish = (Button) findViewById(R.id.createWish);

        creatNewWish.setOnClickListener(this);

        descript = (EditText) findViewById(R.id.newWish);

        uploadWishPhoto = (ImageView) findViewById(R.id.uploadWishPhoto);

        uploadWishPhoto.setOnClickListener(this);

        setTitle(getString(R.string.CreateWishTitle));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.createWish:
                if (descript.length() < 10)
                    Toast.makeText(createNewWish.this, getString(R.string.WriteMore), Toast.LENGTH_SHORT).show();
                else {
                    s = descript.getText().toString();
                    new addWish().execute("");
                }
                break;
            case R.id.uploadWishPhoto:
                selectImage();
            default:
                break;
        }
    }

    private void selectImage() {

        final CharSequence[] options = { getString(R.string.TakePhoto), getString(R.string.Choose),getString(R.string.Cancel) };

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.AddPhoto));
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (options[item].equals(options[0]))
                {
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    File f = new File(android.os.Environment.getExternalStorageDirectory(), "temp.jpg");
                    intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(f));
                    startActivityForResult(intent, 1);
                }
                else if (options[item].equals(options[1]))
                {
                    Intent intent = new   Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(intent, 2);

                }
                else if (options[item].equals(options[2])) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == this.RESULT_OK) {
            if (requestCode == 1) {
                File f = new File(Environment.getExternalStorageDirectory().toString());
                for (File temp : f.listFiles()) {
                    if (temp.getName().equals("temp.jpg")) {
                        f = temp;
                        break;
                    }
                }
                try {
                    BitmapFactory.Options bitmapOptions = new BitmapFactory.Options();

                    bitmap = BitmapFactory.decodeFile(f.getAbsolutePath(),
                            bitmapOptions);

                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.PNG, 90, stream);
                    byte[] image = stream.toByteArray();
                    String img_str = Base64.encodeToString(image, 0);
                    byte[] imageAsBytes = Base64.decode(img_str.getBytes(), Base64.DEFAULT);
                    uploadWishPhoto.setImageBitmap(BitmapFactory.decodeByteArray(imageAsBytes, 0, imageAsBytes.length));
                    uploaded = 1;

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            else if (requestCode == 2) {

                Uri selectedImage = data.getData();
                String[] filePath = { MediaStore.Images.Media.DATA };
                Cursor c = this.getContentResolver().query(selectedImage,filePath, null, null, null);
                c.moveToFirst();
                int columnIndex = c.getColumnIndex(filePath[0]);
                String picturePath = c.getString(columnIndex);
                c.close();
                bitmap = (BitmapFactory.decodeFile(picturePath));
                ByteArrayOutputStream stream=new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 90, stream);
                byte[] image=stream.toByteArray();
                String img_str = Base64.encodeToString(image, 0);
                byte[] imageAsBytes = Base64.decode(img_str.getBytes(), Base64.DEFAULT);
                uploadWishPhoto.setImageBitmap(BitmapFactory.decodeByteArray(imageAsBytes,0, imageAsBytes.length) );
                uploaded = 1;

            }

        }
    }



    private class addWish extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... params) {
            InputStream in = null;
            if (uploaded == 1) {
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
                in = new ByteArrayInputStream(stream.toByteArray());
            }

            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            MultipartEntity multipartEntity = new MultipartEntity();
            multipartEntity.addPart("code", "addWish");
            multipartEntity.addPart("user_id",sPref.getString("userId", null));
            multipartEntity.addPart("wish", s);
            if (uploaded == 1) {
                multipartEntity.addPart("check", "fignya");
                multipartEntity.addPart("image", System.currentTimeMillis() + ".jpg", in);
            }
            else
                multipartEntity.addPart("check", "false");

            httpPost.setEntity(multipartEntity);

            HttpResponse httpResponse = null;
            try {
                httpResponse = httpClient.execute(httpPost);
                HttpEntity entity = httpResponse.getEntity();
                response = EntityUtils.toString(entity);

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        ProgressDialog dialog;

        @Override
        protected void onPreExecute(){
            super.onPreExecute();
            dialog = ProgressDialog.show(createNewWish.this,"",getString(R.string.Loading),true,true);
            dialog.show();

        }

        @Override
        protected void onPostExecute(Void o) {
            super.onPostExecute(o);
            if (response != null) {
                Toast.makeText(createNewWish.this, getString(R.string.AddedWish), Toast.LENGTH_SHORT).show();
                onBackPressed();
                finish();
                dialog.dismiss();
            }
            else{
                dialog.dismiss();
                Toast.makeText(createNewWish.this, getString(R.string.NoInternetConnection),Toast.LENGTH_SHORT).show();
            }
        }

    }
}
